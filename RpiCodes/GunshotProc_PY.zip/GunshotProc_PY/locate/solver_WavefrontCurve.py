#!/usr/bin/python 

#  \brief class for solving source location based on wavefront curvature in 2D
#  \author A. Sinha

import numpy as np
import math

from . import SolverTemplate

# machine precision (epsilon) for my checks of closeness to zero
my_eps = 1.e3*np.finfo(np.float64).eps

class WaveFrontCurveMethod(SolverTemplate):
    """ class for solving source location based on wavefront curvature in 2D
    
        ATTRIBUTES: see parent class
        
        METHODS:
        _calcSrcLocClstr: calculate possible source location(s) based on data
                          recorded on a cluster of sensors
    """

    def _calcSrcLocClstr(self,iClstr,options):
        """ calculate list of possible source locations from data on cluster
            index 'iClstr'
            
            ASSUMPTIONS:
            1.  cluster is planar with 3 sensors in z=const plane (first 3
                sensors in cluster are used, and all others are ignored)
            2.  Does not check whether all sensors are in same z-plane, but
                returns source location solutions with z-coordinate as that of
                cluster centroid
            
            INPUTS:
            iClstr:  index of cluster in environment
            options: dict of solver options (booleans are False by default)
                autoReorder: automatically reorder sensors to improve accuracy
                plot:        plot the results and sensors
                debug:       write out (to standard output) debugging info

            OUTPUT:
            srcLocs: list of possible source location coordinates (each list
                     element is a 3-element numpy 1D-array)
        """

        clstr = self.env.Clusters[iClstr] #retrieve 'Cluster' object
        
        sndSpd = self.env.config.sndSpd
#        dt = self.env.config.dt

        # determine sensor order (list of indices into 'Sensors' list of
        # cluster); use first 3 sensors in cluster, and 0th is common
        snsrOrder = [0,1,2] #default sensor order
        if 'autoReorder' in options and options['autoReorder']:
            # automatically reorder
            snsrOrder = self.getBestSensorOrder(iClstr,snsrIdsIn=snsrOrder)
        
        # source location's z-coordinate is always returned as that of centroid
        # of specified sensors (always first three in cluster)
        srcLocZ = clstr.calcCentroid(snsrOrder)[-1]
        
        # inter-sensor distances from common sensor
        d10 = clstr.Dists[snsrOrder[0],snsrOrder[1]]
        d20 = clstr.Dists[snsrOrder[0],snsrOrder[2]]
        # normalized time taken by event to reach sensor 1 minus that to 0
        eta10 = clstr.Delays[snsrOrder[0],snsrOrder[1]]*sndSpd/d10
        # normalized time taken by event to reach sensor 2 minus that to 0
        eta20 = clstr.Delays[snsrOrder[0],snsrOrder[2]]*sndSpd/d20
        
        if abs(eta10) >= 1. or abs(eta20) >= 1.:
            return None, None, None

        # angle (w.r.t. +ve x-axis) of line joining sensor 0 to 1
        thetaSensor10 = clstr.interSnsrAngHz(snsrOrder[1],snsrOrder[0])
        
        # determine angle between Sensors 0-1 arm and Sensors 0-2 arm
        vect10 = clstr.Sensors[snsrOrder[1]].coords-clstr.Sensors[snsrOrder[0]].coords
        vect20 = clstr.Sensors[snsrOrder[2]].coords-clstr.Sensors[snsrOrder[0]].coords
        cosGamma = np.dot(vect10,vect20)/(d10*d20)
        vect1020 = np.cross(vect10,vect20)
        if vect1020[-1] > 0.:
            Gamma = math.acos(cosGamma)
        else:
            Gamma = -math.acos(cosGamma)
        
        # find bearing angle (denoted 'srcTheta') w.r.t. Sensor 0-1 arm
        if abs(eta10) > 1. - my_eps: #source is collinear w/ Sensors 0-1
            if eta10 > 0.: #sound takes longer to reach Sensor 1 than Sensor 0
                # source and Sensor 1 are on opposite sides of Sensor 0
                srcThetas = [math.pi]
            else: #sound takes longer to reach Sensor 0 than Sensor 1
                # soure and Sensor 1 are on same side of Sensor 0
                srcThetas = [0.]
        elif abs(eta20) > 1. - my_eps: #source is collinear w/ Sensors 0-2
            if eta20 > 0.: #sound takes longer to reach Sensor 2 than Sensor 0
                # source and Sensor 2 are on opposite sides of Sensor 0
                srcThetas = [Gamma - math.pi]
            else: #sound takes longer to reach Sensor 0 than Sensor 2
                # soure and Sensor 2 are on same side of Sensor 0
                srcThetas = [Gamma]
        else: #source isn't collinear w/ either Sensors 0-1 or Sensors 0-2
            fctrA = d20/d10*(1-eta20**2)/(1-eta10**2) #a factor
            alpha = math.atan2(math.sin(Gamma),math.cos(Gamma)-fctrA) #an angle
            cosBeta = (fctrA*eta10-eta20)/math.sqrt(1+fctrA**2 \
                -2*fctrA*math.cos(Gamma)) #cos of another angle
            if abs(cosBeta) > 1.:
                return None, None, None
#            cosBeta = max(min(cosBeta,+1.),-1.)
            beta = math.acos(cosBeta)
            srcThetas = [alpha + beta, alpha - beta] #two solutions

        if 'debug' in options and options['debug']:
            print 'eta10 = ',eta10,', eta20 = ',eta20, \
                beta*180./math.pi,', srcThetas = ', \
                ', fctrA = ',fctrA,', alpha = ',alpha*180./math.pi,', beta = ',\
                [srcThetas[0]*180./math.pi, srcThetas[1]*180./math.pi]
        
        # internal function to get valid source location from bearing angle
        def getValidSoln(srcTheta):
            # use range expression from Sensors 0-1
            srcRange = d10*(1-eta10**2)/(2*(eta10+math.cos(srcTheta)))
            if srcRange < 0.:
                return None, None
            # calculate absolute source angle
            srcThetaAbs = srcTheta + (thetaSensor10 - math.pi)
            # calculate absolute x-location of source
            srcLocX = clstr.Sensors[snsrOrder[0]].coords[0] \
                +srcRange*math.cos(srcThetaAbs)
            # calculate absolute y-location of source
            srcLocY = clstr.Sensors[snsrOrder[0]].coords[1] \
                +srcRange*math.sin(srcThetaAbs)
            # source's absolute z-location is preset as that of cluster centroid
            srcLoc = np.array([srcLocX,srcLocY,srcLocZ])
            # distance of above-calculated source location from sensor 1
            srcRange1 = np.linalg.norm(srcLoc \
                - clstr.Sensors[snsrOrder[1]].coords)
            # distance of above-calculated source location from sensor 2
            srcRange2 = np.linalg.norm(srcLoc \
                - clstr.Sensors[snsrOrder[2]].coords)
            if srcRange1 < 0. or srcRange2 < 0.:
                return None, None
            if 'debug' in options and options['debug']:
                print 'srcThetaAbs = ',srcThetaAbs*180./math.pi, \
                    ', srcRange = ',srcRange,', srcLoc = ',srcLoc
            # verify that difference in path length from source to sensor 2
            # (i.e. 'distSrcSens2') and that from source to sensor 0 (which
            # is 'srcRange') equals the speed of sound times the DTOA
            # at sensors 2 & 0
            if abs(eta10*d10 - (srcRange1-srcRange)) > my_eps or \
                abs(eta20*d20 - (srcRange2-srcRange)) > my_eps:
                if 'debug' in options and options['debug']:
                    print 'error10 = ',abs(eta10*d10 - (srcRange1-srcRange)),\
                        ', error20 = ',abs(eta20*d20-(srcRange2-srcRange))
                return None, None
            else:
                error = abs(eta10*d10-(srcRange1-srcRange)) + abs(eta20*d20-(srcRange2-srcRange))
                snsr_ref = snsrOrder[0]
                return srcLoc, error

        # initialize empty list of possible solutions
        srcLocs = []
        errors = []
        snsr_refs = []
        for srcTheta in srcThetas: #go thru all candidate solutions of srcTheta
            # valid source location solution from srcTheta ('None' if invalid)
            srcLoc, error = getValidSoln(srcTheta)
            if srcLoc is not None:
                srcLocs.append(srcLoc)
                errors.append(error)
                snsr_refs.append(snsrOrder[0]) #Reference sensor is always the 0th one

        if len(srcLocs) <> 0:
            if 'plot' in options and options['plot']:
                self._plotSolnsClstr(iClstr,srcLocs,snsrOrderIn=snsrOrder)
        else:
            if 'debug' in options and options['debug']:
                print 'eta10 = ',eta10,', eta20 = ',eta20, \
                    ', srcThetas = ',[th*180./math.pi for th in srcThetas]
            
        return srcLocs, errors, snsr_refs

    # enddef _calcSrcLocClstr

#endclass Solver





##!/usr/bin/python 
#
##  \brief class for solving source location based on wavefront curvature in 2D
##  \author A. Sinha
#
#import numpy as np
#import math
#from matplotlib import pyplot as plt
#
#from . import SolverTemplate
#
## machine precision (epsilon) for my checks of closeness to zero
#my_eps = 1.e3*np.finfo(np.float64).eps
#
#class WaveFrontCurveMethod(SolverTemplate):
#    """ class for solving source location based on wavefront curvature in 2D
#    
#        ATTRIBUTES: see parent class
#        
#        METHODS:
#        _calcSrcLocClstr: calculate possible source location(s) based on data
#                          recorded on a cluster of sensors
#    """
#
#    def _calcSrcLocClstr(self,iClstr,options):
#        """ calculate list of possible source locations from data on cluster
#            index 'iClstr'
#            
#            ASSUMPTIONS:
#            1.  cluster is planar with 3 sensors in z=const plane (first 3
#                sensors in cluster are used, and all others are ignored)
#            2.  Does not check whether all sensors are in same z-plane, but
#                returns source location solutions with z-coordinate as that of
#                cluster centroid
#            
#            INPUTS:
#            iClstr:  index of cluster in environment
#            options: dict of solver options (booleans are False by default)
#                autoReorder: automatically reorder sensors to improve accuracy
#                plot:        plot the results and sensors
#                debug:       write out (to standard output) debugging info
#
#            OUTPUT:
#            srcLocs: list of possible source location coordinates (each list
#                     element is a 3-element numpy 1D-array)
#        """
#
#        clstr = self.env.Clusters[iClstr] #retrieve 'Cluster' object
#        
#        sndSpd = self.env.config.sndSpd
#        dt = self.env.config.dt
#
#        # determine sensor order (list of indices into 'Sensors' list of
#        # cluster); use first 3 sensors in cluster, and 0th is common
#        snsrOrder = [0,1,2] #default sensor order
#        if 'autoReorder' in options and options['autoReorder']:
#            # automatically reorder
#            snsrOrder = self.getBestSensorOrder(iClstr,snsrIdsIn=snsrOrder)
#        
#        # source location's z-coordinate is always returned as that of centroid
#        # of specified sensors (always first three in cluster)
#        srcLocZ = clstr.calcCentroid(snsrOrder)[-1]
#        
#        # inter-sensor distances from common sensor
#        d10 = clstr.Dists[snsrOrder[0],snsrOrder[1]]
#        d20 = clstr.Dists[snsrOrder[0],snsrOrder[2]]
#        # normalized time taken by event to reach sensor 1 minus that to 0
#        eta10 = clstr.IDelays[snsrOrder[0],snsrOrder[1]]*dt*sndSpd/d10
#        # normalized time taken by event to reach sensor 2 minus that to 0
#        eta20 = clstr.IDelays[snsrOrder[0],snsrOrder[2]]*dt*sndSpd/d20
#
#        # angle (w.r.t. +ve x-axis) of line joining sensor 0 to 1
#        thetaSensor10 = clstr.interSnsrAngHz(snsrOrder[1],snsrOrder[0])
#        # angle (w.r.t. +ve x-axis) of line joining sensor 1 to 2
#        thetaSensor02 = clstr.interSnsrAngHz(snsrOrder[0],snsrOrder[2])
#        # angle between above two lines
#        delta = thetaSensor10 - thetaSensor02
#        # theta0 is the bearing angle if 'delta' is 0; we find the numerator and
#        # denominator of the fraction that expresses cos(theta0)
#        numCTheta0 = eta20*d10*(1-eta10**2) - eta10*d20*(1-eta20**2)
#        denCTheta0 = d10*(1-eta10**2) + d20*(1-eta20**2)
#        CTheta0 = numCTheta0/denCTheta0
#        # an intermediate variable
#        zeta = d10*(1-eta10**2)/denCTheta0
#        # coefficients of the quadratic equation for cos(srcTheta), where
#        # srcTheta is the bearing angle of the source w.r.t. the line joining
#        # sensors 1 and 0
#        coeffA = (1-zeta+zeta*math.cos(delta))**2+(zeta*math.sin(delta))**2
#        coeffB = -2*CTheta0*(1-zeta+zeta*math.cos(delta))
#        coeffC = CTheta0**2-(zeta*math.sin(delta))**2
#        coeffDscrmnt = coeffB**2-4*coeffA*coeffC #discriminant
#        if coeffDscrmnt < 0:
##            raise Exception('Encountered -ve discriminant')
#            return []
#        # two solutions for cos(srcTheta)
#        cSrcTheta1 = (-coeffB+math.sqrt(coeffDscrmnt))/(2*coeffA)
#        cSrcTheta2 = (-coeffB-math.sqrt(coeffDscrmnt))/(2*coeffA)
#
#        # create list of all valid srcTheta's: +ve and -ve acos() of cSrcTheta1
#        # and cSrcTheta2, if they are valid cosines
#        srcThetas = []
#        if abs(cSrcTheta1) <= 1.: #first solution is a valid cosine
#            srcTheta1p = math.acos(cSrcTheta1) #correpsonding +ve angle
#            srcThetas += [srcTheta1p, -srcTheta1p] #append it & its -ve to list
#        if abs(cSrcTheta2) <= 1.: #second solution is a valid cosine
#            srcTheta2p = math.acos(cSrcTheta2) #correpsonding +ve angle
#            srcThetas += [srcTheta2p, -srcTheta2p] #append it & its -ve to list
#
#        # internal function to get valid source location solution for theta
#        # (bearing angle from sensor 1, w.r.t. arm joining sensor 1 to sensor 0)
#        def getValidSoln(srcTheta):
#            # calculate source range (from Sensor 1) based on supplied srcTheta
#            srcRange = d10*(1-eta10**2)/(2*(eta10 + math.cos(srcTheta)))    
#            # calculate absolute source angle
#            srcThetaAbs = srcTheta + (thetaSensor10 - math.pi)
#            # calculate absolute x-location of source
#            srcLocX = clstr.Sensors[snsrOrder[0]].coords[0] \
#                +srcRange*math.cos(srcThetaAbs)
#            # calculate absolute y-location of source
#            srcLocY = clstr.Sensors[snsrOrder[0]].coords[1] \
#                +srcRange*math.sin(srcThetaAbs)
#            # source's absolute z-location is preset as that of cluster centroid
#            srcLoc = np.array([srcLocX,srcLocY,srcLocZ])
#            # distance of above-calculated source location from sensor 2
#            distSrcSens2 = np.linalg.norm(srcLoc \
#                - clstr.Sensors[snsrOrder[2]].coords)
#            # verify that difference in path length from source to sensor 2
#            # (i.e. 'distSrcSens2') and that from source to sensor 1 (which is
#            # 'srcRange') equals the speed of sound times the differential
#            # time-of-arrival at sensors 2 & 1
#            if abs(eta20*d20 - (distSrcSens2-srcRange)) > my_eps:
#                return None
#            else:
#                return srcLoc
#
#        # initialize empty list of possible solutions
#        srcLocs = []
#        for srcTheta in srcThetas: #go thru all candidate solutions of srcTheta
#            # valid source location solution from srcTheta ('None' if invalid)
#            srcLoc = getValidSoln(srcTheta)
#            if srcLoc is not None:
#                srcLocs.append(srcLoc)
#
#        if len(srcLocs) <> 0:
#            if 'plot' in options and options['plot']:
#                self._plotSolnsClstr(iClstr,srcLocs,snsrOrderIn=snsrOrder)
#            
#        return srcLocs
#
#    # enddef _calcSrcLocClstr
#
##endclass Solver
