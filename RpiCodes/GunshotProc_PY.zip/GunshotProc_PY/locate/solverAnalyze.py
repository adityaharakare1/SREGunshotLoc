#!/usr/bin/python 

#  \brief Driver routine for gunshot localization
#  \author A. Sinha

import math, os, copy
import numpy as np
from matplotlib import pyplot as plt

import tools, locate, sim

def SolverAnalyze(filename,dataFldr='.'):

    config = sim.Config_GunshotSim(filename)
    
    snsrD = float(config.snsrD)
    srcR = float(config.srcR)
    srcDTheta = float(config.srcDTheta)

    snsrCentroidalArm = snsrD*math.sin(math.pi/3)*2./3.
    
    snsrCoords = np.zeros((3,3),dtype=np.float)
    for iSnsr in range(3):
        ang = 2.*math.pi/3*iSnsr
        snsrCoords[iSnsr,0] = math.cos(ang)*snsrCentroidalArm
        snsrCoords[iSnsr,1] = math.sin(ang)*snsrCentroidalArm

    np.savetxt(tools.environmentSim.filenameSensLoc,snsrCoords)
    
    nTheta = int(math.floor(180./srcDTheta))+1
    
    slvrOptions = {'plot': False,
                   'debug': False,
                   'autoReorder': True}

    thetas = [iTheta*srcDTheta for iTheta in range(nTheta)]

    errBrng = np.zeros((nTheta),dtype=np.float)
    errRange = np.zeros((nTheta),dtype=np.float)
    for iTheta in range(nTheta):
        theta = thetas[iTheta]*math.pi/180.
        
        if 'debug' in slvrOptions and slvrOptions['debug']:
            print 'theta = ',thetas[iTheta]
        srcLoc = np.array([math.cos(theta),math.sin(theta),0.])*srcR

        konfig = copy.deepcopy(config)
        konfig.srcLoc = list(srcLoc)
        gnsht = sim.GunshotSgntrSim(konfig,dataFldr=dataFldr)
        gnsht.sim()

        env = tools.Environment(config,dataFldr=dataFldr)
        env.rtrvData()
        
        slvr = locate.WaveFrontCurveMethod(env)
        slvr.calcSrcLocClstrAvg(slvrOptions)
        
        if not len(slvr.srcLocs):
            errBrng[iTheta] = np.nan
            errRange[iTheta] = np.nan
            continue

        slvRs = np.array([np.linalg.norm(loc) for loc in slvr.srcLocs])
        
        iLoc = np.argmin(np.abs(slvRs - srcR))
#        iLoc = np.argmax(slvRs)
        
        slvLoc = slvr.srcLocs[iLoc]
        
        slvR = np.linalg.norm(slvLoc)
        slvBrng = math.atan2(slvLoc[1],slvLoc[0])
        if theta > math.pi/2:
            if slvBrng < -math.pi/2:
                slvBrng += 2*math.pi
        
        errRange[iTheta] = abs(slvR - srcR)
        errBrng[iTheta] = abs(slvBrng - theta)


#    np.savetxt(os.path.join(dataFldr,'thetas.txt'),thetas)
#    np.savetxt(os.path.join(dataFldr,'errOptmBrng.txt'),errBrng*180./math.pi)
#    np.savetxt(os.path.join(dataFldr,'errOptmRange.txt'),errRange/srcR)
#    np.savetxt(os.path.join(dataFldr,'errOptmBrngMax.txt'), \
#        np.max(errBrng,axis=1)*180./math.pi)
#    np.savetxt(os.path.join(dataFldr,'errOptmRangeMax.txt'), \
#        np.max(errRange,axis=1)/srcR)

#    errBrngAvg = np.zeros((nTheta),dtype=np.float)
#    errRangeAvg = np.zeros((nTheta),dtype=np.float)
#    for iTheta in range(nTheta):
#        tmp = errBrng[iTheta,:]
#        Tmp = tmp[~np.isnan(tmp)] #remove nan's
#        errBrngAvg[iTheta] = np.average(Tmp)
#        tmp = errRange[iTheta,:]
#        Tmp = tmp[~np.isnan(tmp)] #remove None's
#        errRangeAvg[iTheta] = np.average(Tmp)

    plt.figure()
    plt.subplot(2,1,1)
    plt.plot(thetas,errRange/srcR)
    plt.ylim([0,2])
    plt.subplot(2,1,2)
    plt.semilogy(thetas,errBrng*180./math.pi)
    plt.show()
