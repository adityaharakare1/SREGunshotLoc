#!/usr/bin/python 

#  \brief calibrating sensor array w/ data recorded of shots from known locations
#  \author A. Sinha

import os, shutil, math, copy, warnings
import numpy as np
from scipy.optimize import minimize

from MyPythonCodes.tools import redirect, misc_utils

from tools import dataAccess, environment

# File where sensor location info is stored after calibration
filenameSensLocClbrtd = 'sensor_locations_calibrated.txt'
# Template of filename where original (uncalibrated) sensor location info is
# stored before the latter is overwritten by the calibrated location info
filenameSensLocUnClbrtdTmplt = 'sensor_locations_initial_%s.txt'

class ArrayCalibration(object):
    """ class for calibrating sensor array with data recorded of shots from
        known locations        
        
        ASSUMPTIONS:
        1.  Shot data is available in folder structure per 'DataAccess' class
        2.  Log file exists (per 'DataAccess' class format) that records the
            locations from which the shots were fired
        3.  Muzzle blast waves travel spherically from gun with user-specified
            speed of sound
        4.  All sensors have line-of-sight to shot location
        
        ATTRIBUTES:
        projPath: path to project folder where shot data is available
        project:  object of 'DataAccess' class
        env:      Environment object corresponding to 1st event of first data
                  folder in project
        snsrLocs0:initial guess of sensor locations, retrieved from 'env' above
        snsrLocs: calibrated sensor locations
        
        METHODS:
        _calibrateClstr:    calibrate sensor locations in a cluster
        calibrate:          call '_calibrateClstr' for each cluster in
                            environment, and save result in a text file
        supplantSrcLocFile: supplant original sensor locations file (used for
                            initial guess) with calibrated locations file
    """

    def __init__(self,projPath='.'):
        """ initialize class
        
            INPUTS:
            projPath: path to project folder; default: current working directory
        """
        self.projPath = projPath
        self.project = dataAccess.DataAccess(self.projPath) #make project object
        self.project.readLog() #read log file
        self.project.getFldrStruct() #get folder structure in project
        
        # retrieve environment object from 1st event of first data folder
        fldr0 = self.project.fldrStruct[0][0]
        evntFldr00 = self.project.fldrStruct[0][1][0][0]
        with redirect.folder(os.path.join(self.projPath,fldr0,evntFldr00)):
            self.env = environment.Environment(dataAccess.configFname)
        
        # array to hold all initial guesses of sensor locations; pre-allocate
        self.snsrLocs0 = np.zeros((self.env.nSensors,3),dtype=np.float)
        for clstr in self.env.Clusters: #go thru each cluster
            for snsr in clstr.Sensors: #go thru each sensor in cluster
                # insert sensor's coordinates in its proper row 
                self.snsrLocs0[snsr.sensorNo,:] = snsr.coords
        
        # final calibrated sensor locations array, 'None' for now
        self.snsrLocs = None

    def _calibrateClstr(self,iClstr,options=None):
        """ uses time-difference-of-arrival (TDOA) to calibrate a cluster of
            sensors with nonlinear least-squares method
            
            INPUTS:
            iClstr:  index of sensor cluster in environment to calibrate
            options: dict of calibrator options (booleans are False by default)
                bndFctr: fraction of maximum inter-sensor distance to use for
                         establishing a cuboid bound of solutions around initial
                         guess ('None' indicates no bound)
                debug:   write out (to standard output) debugging info
            
            OUTPUTS:
            snsrLocsSoln: numpy 2D-array of calibrated sensor locations -
                          sensors along rows and coordinates along columns  
        """
        sndSpd = self.env.config.sndSpd
#        dt = self.env.config.dt
        nSensors = self.env.Clusters[iClstr].nSensors

        # compose list of 2-tuples containing source and TDOA data for cluster
        Data = []
        # compose list of all folders (datasets) in project, in the order in
        # which they are registered in the project log
        logFldrsAll = [x[0] for x in self.project.log]
        for fldrTuple in self.project.fldrStruct: #go thru project folder struct
            fldr = fldrTuple[0] #first entry is folder name
            # determine index of project log corresponding to this folder
            iLog = [i for i,x in enumerate(logFldrsAll) if fldr == x]
            if len(iLog) <> 1:
                raise Exception('Incorrect project log entries for '+fldr)
            evntFldrs = fldrTuple[1] #second entry is list of event folders
            for evntFldrInfo in evntFldrs: #go thru all event folders
                evntFldr = evntFldrInfo[0] #get event folder name
                evntNo = evntFldrInfo[1] #get corresponding event number
                with redirect.folder(os.path.join(self.projPath,fldr,evntFldr)):
                    if 'ALL' in self.project.log[iLog[0]][1]:
                        # retrieve source location for all events
                        srcLoc = self.project.log[iLog[0]][1]['ALL']
                    else:
                        srcLoc = self.project.log[iLog[0]][1][str(evntNo)]
                    # retrieve environment object and data for this event
                    env = environment.Environment(dataAccess.configFname)
                    env.rtrvData()
                # time delays between 0th sensor and all others in cluster for
                # this event
                Delays = env.Clusters[iClstr].Delays[0,:]
                Data.append((srcLoc,Delays)) #append tuple to 'Data'
                
        def _packSoln(snsrLocsSoln):
            # pack numpy 2D-array of sensor coordinates into a flat list
            return list(np.array(snsrLocsSoln).flatten())

        def _unpackSoln(soln):
            # unpack solution in the form of a flat list into a numpy 2D-array
            # of sensor coordinates
            return np.reshape(soln,(nSensors,3))

        def _costFnc(candidate):
            """ Cost function is sum of squares of error between propagation
                path differences from source to a sensor pair and the TDOA for
                the same pair multiplied by speed of sound; the sum is over all
                sensors (other than the common sensor in the pairings), and all
                events
            """
            snsrLocs = _unpackSoln(candidate) #get candidate sensor locations
            retval = 0. #initialize running sum
            for evntDat in Data: #run through all events in 'Data'
                srcLoc = evntDat[0] #retrieve source location for this event
                tDelays = evntDat[1] #retrieve array of TDOAs for this event
                # distance between source and common sensor (0th in cluster)
                distRef = math.sqrt(np.sum((snsrLocs[0,:]-srcLoc)**2))
                for iSnsr in range(1,nSensors): #run thru all other sensors
                    # distance between source and this sensor
                    distWrk = math.sqrt(np.sum((snsrLocs[iSnsr,:]-srcLoc)**2))
                    # add square of error as described above
                    retval += (distWrk - distRef - sndSpd*tDelays[iSnsr])**2
            return retval
            
        # pack this cluster's sensor locations' initial guess into form suitable
        # for 'minimize'
        x0 = _packSoln(self.snsrLocs0[self.env.Clusters[iClstr].iSensors,:])
        
        # compose 'bounds' constraint for minimization, if so indicated by user
        # supplying 'bndFctr' in 'options'
        if options is not None and 'bndFctr' in options \
                and options['bndFctr'] is not None: #bound constraints desired
            # find maximum inter-sensor distance        
            maxDist = np.max(self.env.Clusters[iClstr].Dists)
            # bound cube side will be 'bndFctr' times above 'maxDist'
            bndDist = maxDist*options['bndFctr']
            # 'minimize' takes bounds constraint in the form of list of 2-tuples
            # consisting of the lower bound and upper bound for each variable
            # in the problem
            bnds = [] # start an empty list
            for Crd in x0: # run thru each sensor coordinate to be calibrated
                # set lower bound to initial guess minus the 'bndDist', and
                # upper bound to initial guess plus the 'bndDist'
                bnds.append((Crd-bndDist,Crd+bndDist))
        else: #bound constraints are not desired
            bnds = None
        
        # optimization options
        minOptions = {'maxiter': 10000}
        # actual minization
        minRes = minimize(_costFnc,x0,method='TNC',bounds=bnds,tol=1e-10, \
            options=minOptions)

        # report entire result dict if 'debug' mode is indicated        
        if options is not None and 'debug' in options and options['debug']:
            print minRes
        
        # compose solution of calibration
        if minRes.success: #successful minimization
            snsrLocsSoln = _unpackSoln(minRes.x) #unpack solution
        else: #unsuccessful minimization
            snsrLocsSoln = None #set to none

        return snsrLocsSoln
        
    #enddef _calibrateClstr
        
    def calibrate(self,options=None):
        """ calibrate each cluster of sensors in environment separately; then
            save all calibrated sensor locations in a text file in 'projPath'
            
            INPUTS:
            options: see '_calibrateClstr'; also:
                plot: plot the sensor locations before and after calibration
            
            OUTPUTS:
            calibrated: boolean to keep track of whether at least one cluster
                        of sensors could be calibrated successfully
        """
        calibrated = False #see opening comments
        # pre-allocate array to hold all calibrated sensor locations
        self.snsrLocs = np.zeros_like(self.snsrLocs0)
        for iClstr in range(self.env.nClusters): #go thru each cluster
            # get calibrated sensor locations for this cluster
            snsrLocsClstr = self._calibrateClstr(iClstr,options=options)
            if snsrLocsClstr is None: #calibration was unsuccessful
                warnings.warn('Cluster '+str(iClstr)+' calibration failed!')
                continue #on to next cluster
            #   execution comes here if calibration was successful
            # insert calibrated sensors' coordinates in their proper rows
            self.snsrLocs[self.env.Clusters[iClstr].iSensors,:] = snsrLocsClstr
            calibrated = True
            # plot calibrated sensor locations in this cluster  
            if options is not None and 'plot' in options and options['plot']:
                # plot initial guess of sensor locations in this cluster  
                if iClstr == 0:
                    fignum = None
                fignum = self.env.Clusters[iClstr].plot(fignum=fignum)
                # copy cluster object
                cpyClstr = copy.deepcopy(self.env.Clusters[iClstr])
                for iSnsr in range(cpyClstr.nSensors): #go thru sensors
                    # replace initial guess sensor coordinates by calibrated
                    # ones in copy of cluster object
                    cpyClstr.Sensors[iSnsr].coords = snsrLocsClstr[iSnsr,:]
                # plot sensors of calibrated cluster in same figure
                fignum = cpyClstr.plot(fmt='rx-.',fignum=fignum)
        # save calibrated sensor locations in text file
        if calibrated:
            np.savetxt(os.path.join(self.projPath,filenameSensLocClbrtd), \
                self.snsrLocs)
        return calibrated
    #enddef calibrate

    def supplantSrcLocFile(self):
        """ copy original sensor locations file to a different file; then
            supplant the former file with the calibrated locations file
        """
        # split filename template for uncalibrated sensor locations with '%s'
        # (where the non-negative integer will enter)
        nameParts = filenameSensLocUnClbrtdTmplt.split('%s')
        # get postfix of file name (part following '%s')
        if len(nameParts) == 1:
            namePost = "" #no postfix
        else:
            namePost = nameParts[1] #second part is postfix
        # determine next available file name with above template
        nameNext = misc_utils.nextFile(nameParts[0],namePost=namePost, \
            parent=self.projPath)
        with redirect.folder(self.projPath):
            # copy original sensor locations file to above-determined file
            shutil.copyfile(environment.filenameSensLoc,nameNext)
            # supplant original sensor locations file with calibrated locations
            # file
            shutil.copyfile(filenameSensLocClbrtd,environment.filenameSensLoc)
    #endsupplantSrcLocFile

#endclass ArrayCalibration

def rtrvCalibrated(projPath):
    # read and return calibrated coordinates of all sensors in environment
    # from tabulated file in 'projPath' whose row index corresponds to sensor
    # index
    return np.loadtxt(os.path.join(projPath,filenameSensLocClbrtd), \
        comments="#")
#enddef rtrvCalibrated
