#!/usr/bin/python 

#  \brief Sighting vector method of source location applied to TDOA
#  \author A. Sinha

import math, warnings
import numpy as np

from . import SolverTemplate

# machine precision (epsilon) for my checks of closeness to zero
my_eps = 1.e6*np.finfo(np.float64).eps

class SightVectMethod(SolverTemplate):
    """ class for implementing unit-sighting-vector-based method of source
        localization
    
        ATTRIBUTES: see parent class for attributes. Also,
        dca: distance of closest approach between best pair of sighting vectors
        
        METHODS:
        calcSrcLoc:     determine most probable source location (unique) based
                        on unit sighting vectors obtained from all clusters
        SightVectClstr: calculate unit sighting vector of source based on data
                        recorded on a cluster of sensors
    """
    
    def calcSrcLoc(self,options=None):
        """ Calculate most probable source location based on unit sighting
            vectors calculated using data recorded on all clusters.

            ASSUMPTIONS AND ACTIONS:
            1.  Each cluster can yield one or at most two possible unit sighting
                vectors
            2.  We go thru all possible pairs of clusters to find the pair of
                sighting vectors that have the closest approach
            3.  The most probable source location is the bisector of the line
                joining the points of closest approach on the above pair of
                sighting vectors. We also store the corresponding distance of
                closest approach.
            
            INPUTS:
            options: dict of solver options (booleans are False by default)
                     including (but not limited to) the following keywords
                plot:        plot the results and sensors
                debug:       write out (to standard output) debugging info
        """
        nClusters = self.env.nClusters
        if nClusters < 2:
            raise Exception('At least 2 clusters needed for sighting vector')
        debug = options and 'debug' in options and options['debug']
        # initialize empty list to store sighting vector(s) and other metadata
        # for each cluster separately
        sightVects = []
        for iClstr in range(nClusters): #go thru all clusters in env
            # Obtain sighting vector(s) based on data recorded on this cluster
            vectsCurr, origCurr, corrCurr = self.SightVectClstr(iClstr,options)
            if vectsCurr is None:
                raise Exception('Cannot have useless cluster')
            # append tuple of above results
            sightVects.append((vectsCurr,origCurr,corrCurr))
            if debug:
                print 'calcSrcLoc: iClstr=',iClstr,', vectsCurr=',vectsCurr, \
                    ', sndSpdCorr = ',corrCurr
        # intialize 'best' solutions for source location and corresponding
        # distance of closest approach 
        srcLocBest = np.zeros((3)) #best solution of source location (dummy)
        dcaBest = 1./my_eps #best solution of dca till now should be inf
        # go thru each pair of clusters to determine best solution (based on
        # minimum distance of closest approach)        
        for iClstr in range(nClusters):
            origI = sightVects[iClstr][1]
            for jClstr in range(iClstr+1,nClusters):
                origJ = sightVects[jClstr][1]
                nVectsI = len(sightVects[iClstr][0])
                nVectsJ = len(sightVects[jClstr][0])
                # declare empty array to store solutions from all possible
                # pairings of sighting vectors retrieved from current pair of
                # clusters
                solns = np.recarray((nVectsI,nVectsJ), \
                    dtype=[('dca',float),('srcLoc',(float,3))])
                # go thru each pair of sighting vectors one from each cluster in
                # pair
                for ik in range(nVectsI):
                    vectIK = sightVects[iClstr][0][ik]
                    for jk in range(nVectsJ):
                        vectJK = sightVects[jClstr][0][jk]
                        # calculate closest approach between current pair of
                        # sighting vectors
                        dca,Pc1,Pc2 =_closestApproach(origI,vectIK,origJ,vectJK)
                        # insert current solution for source location and dca
                        solns[ik,jk] = (dca,(Pc1+Pc2)/2.)
                # determine solution with minimum distance of closest approach
                kBest = np.unravel_index(solns['dca'].argmin(), \
                    solns['dca'].shape)
                if solns['dca'][kBest] < dcaBest: #current min is global min yet
                    dcaBest = solns['dca'][kBest] #update global min dca
                    srcLocBest = solns['srcLoc'][kBest] #update source location
        self.srcLocs = [srcLocBest] #assign as attribute
        self.dca = dcaBest #assign as attribute
    #enddef calcSrcLoc

    def SightVectClstr(self,iClstr,options=None):
        """ calculate unit sighting vector of source based on data recorded
            on sensors of a cluster
            
            ASSUMPTIONS AND ACTIONS:
            1.  Speed of sound is known
            2.  The sensors are not all on one line (so there must be at least
                3 sensors). If all the sensors are in a plane, then the problem
                is a 2D one; else it is a 3D one.
            3.  If all sensors are in a plane, the in-plane components of the
                sighting vector can be determined. If there is an out-of-plane
                component, then its sign remains indeterminate. So we return
                both solutions.
            4.  In case of a 3D problem (when all sensors are not in a plane),
                the system of equations is over-determined; thus, it may serve
                to provide additional verification of the assumed speed-of-sound
            
            INPUTS:
            iClstr:  index of cluster in environment
            options: dict of solver options (booleans are False by default)
                autoReorder: automatically reorder sensors, may improve accuracy
                plot:        plot the results and sensors
                debug:       write out (to standard output) debugging info

            OUTPUT:
            sightVect:  list of at most two possible solutions for the unit
                        sighting vector from the cluster to the source
            origin:     origin of vector (coordinates of cluster centroid)
            sndSpdCorr: correction factor for speed of sound (large deviations
                        from unity may indicate faulty data record on cluster)
        """

        debug = options and 'debug' in options and options['debug']
        autoReorder = options and 'autoReorder' in options \
            and options['autoReorder']

        clstr = self.env.Clusters[iClstr] #retrieve 'Cluster' object

        sndSpd = self.env.config.sndSpd #speed of sound
        dt = self.env.config.dt         #sampling period of data

        # number of data points (number of sensors in cluster)
        nSensors = clstr.nSensors
        if nSensors < 3:
            # algorithm for sighting vector requires at least 3 sensors
            warnings.warn('Cluster #'+str(iClstr)+' has less than 3 sensors!')
            return None, None, None

        if autoReorder:
            snsrOrder = self.getBestSensorOrder(iClstr)
        else:
            snsrOrder = range(nSensors)
        Sensors = [clstr.Sensors[iSnsr] for iSnsr in snsrOrder]
        
        # create a (2D) array of vectors pointing from the 0th-sensor to the
        # remaining sensors
        axesAll = np.zeros((nSensors-1,3))
        for iSnsr in range(nSensors-1):
            axesAll[iSnsr,:] = Sensors[iSnsr+1].coords - Sensors[0].coords
        # create a (2D) array of cross product (vectors) between the 0th axis
        # (pointing from the 0th sensor to the 1st one) and the remaining axes;
        # also create a (1D) binary array indicating whether the norms of the
        # above cross products are non-zero (i.e. the axes are not collinear)
        crossProdsAll = np.zeros((nSensors-2,3))
        crossProdsNot0 = np.zeros((nSensors-2))
        for iAxs in range(nSensors-2):
            crossProdsAll[iAxs,:] = np.cross(axesAll[0,:],axesAll[iAxs+1,:])
            crossProdsNot0[iAxs] = np.linalg.norm(crossProdsAll[iAxs,:])>my_eps
        # algorithm for sighting vector requires sensors to be non-collinear
        if not any(crossProdsNot0):
            warnings.warn('Sensors in cluster #'+str(iClstr)+' form a line!')
            return None, None, None

        # determine the index of the first sensor that is NOT collinear with the
        # line joining the first two sensors
        iCross = np.where(crossProdsNot0)[0][0]
        if iCross <> 0:
            #   The first non-collinear sensor is NOT the first one (after the
            #   first two sensors); we swap the sensor order such that the first
            #   three sensors in the array become non-collinear (they would now
            #   define a plane)
            # swap on 'Sensors' list (recall that the first two sensors are
            # not at issue)
            Sensors[2],Sensors[iCross+2] = Sensors[iCross+2],Sensors[2]
            # swap on 'snsrOrder' list (see preceding comments for 'Sensors')
            snsrOrder[2],snsrOrder[iCross+2] = snsrOrder[iCross+2],snsrOrder[2]
            # swap on sensor-to-sensor axes array ('axesAll') (recall that the
            # first sensor-to-sensor axis is not at issue)
            axesAll[[1,iCross+1],:] = axesAll[[iCross+1,1],:]
            # swap on axis-to-first-axis cross-product array ('crossProdsAll')
            # (recall that the index of the first cross-product which was found
            # to be non-zero was 'iCross')
            crossProdsAll[[0,iCross],:] = crossProdsAll[[iCross,0],:]

        # determine whether cluster is planar (two-dimensional) or not
        if nSensors == 3:
            # with three non-collinear sensors, the cluster is of course planar
            twoD = True
        else:
            # determine whether in spite of having more than three sensors, the
            # cluster is still planar; for this we have to ensure that at least
            # one sensor DOES NOT lie in the plane formed by the first 3 sensors
            # (recall that a swap has been made to ensure that the first 3
            # sensors are not collinear)
            planeNormal = crossProdsAll[0,:] #normal to plane of 1st 3 sensors
            planeNormal = planeNormal/np.linalg.norm(planeNormal) #unit normal
            planeLoc = -np.dot(planeNormal,Sensors[0].coords)#offset from origin
            offsets = np.zeros((nSensors-3)) #offsets of other sensors wrt plane
            for iPt in range(nSensors-3): #run thru remaining sensors
                offsets[iPt] = np.dot(planeNormal,Sensors[iPt+3].coords)+planeLoc
            if all(np.abs(offsets) < my_eps): #all offsets are close to 0
                if debug:
                    print '2D: nSensors = ',nSensors,', offsets = ',offsets, \
                        ', planeNormal = ',planeNormal,', planeLoc = ',planeLoc
                twoD = True
            else: #cluster is three-dimensional
                twoD = False

        # array of time delays between 0th sensor and remaining ones
        tau0 = clstr.Delays[snsrOrder[1:],snsrOrder[0]]
        
        if twoD:
            """ The treatment of a 2-D sensor array:
                1.  Define coordinate axis
                    (a) x-axis from 0th sensor to 1st,
                    (b) y-axis orthogonal to x-axis in plane of sensors and in 
                        general direction of 2nd sensor from x-axis (recall that
                        sensors have been ordered such that first 3 are not
                        collinear)
                    (c) z-axis completing the orthonormal basis
                2.  Compute the projection of the unit sighting vector onto the
                    above x-y plane using standard formulation; this problem may
                    be over-determined if more than 3 sensors are present in the
                    planar cluster, in which case a least-squares method is used
                3a. If the length of the above projected vector is less than 1,
                    then there is an out-of-plane component of the unit sighting
                    vector that can be determined up to a sign; this yields two
                    possible solutions for the sighting vector. In this case, we
                    assume that the supplied value of speed of sound is correct
                    so that the corresponding correction factor to be returned
                    is 1.
                3b. If the length of the above projected vector is greater than
                    1, then in reality, the speed of sound was probably lower
                    than the value supplied (the other reasons may be errors in
                    measuring TDOAs, and/or distortions of the wavefront from
                    plane); we re-normalized the vector such that its norm is 1,
                    and set its out-of-plane component to 0 (we don't have any
                    better information). In this case, we also return the
                    indicated correction factor for the speed of sound.
                4.  We return the coordinates of the sighting vector(s) in the
                    absolute coordinate system by suitable transformation using
                    the known x-, y- and z-axes unit vectors in the sensor plane
            """
            # Calculate x-, y- and z-axes unit vectors in sensor plane
            xAxis = axesAll[0,:]
            xAxis = xAxis/np.linalg.norm(xAxis) #unitize
            yAxis = axesAll[1,:]-np.dot(axesAll[1,:],xAxis)*xAxis
            yAxis = yAxis/np.linalg.norm(yAxis) #unitize
            zAxis = np.cross(xAxis,yAxis) #already unitized
            # Compose sensor location data matrix: one less row than the number
            # of sensors, and 2 columns (viz. x- and y-components of directed
            # lines joining 0th sensor to all remaining sensors)
            distVects = np.zeros((nSensors-1,2),dtype=np.float)
            for iSnsr in range(nSensors-1):
                distVects[iSnsr,0] = np.dot(axesAll[iSnsr],xAxis)
                distVects[iSnsr,1] = np.dot(axesAll[iSnsr],yAxis)
            # solve least-squares problem for two components of unit sighting
            # vector in plane of sensors
            vectTmpXY = np.dot(np.linalg.pinv(distVects),tau0)*sndSpd
            # norm of above solution 
            vectTmpXYNorm = np.linalg.norm(vectTmpXY)
            if vectTmpXYNorm < 1:
                # see comment 3a above
                vectTmpZ = math.sqrt(1-np.linalg.norm(vectTmpXY)**2)
                # compose a list of the two possible solutions
                vectTmp = [np.array([vectTmpXY[0],vectTmpXY[1],vectTmpZ]), \
                    np.array([vectTmpXY[0],vectTmpXY[1],-vectTmpZ])]
                # there is no correction that we can find for sound speed
                sndSpdCorr = 1.0
            else:
                # see comment 3b above
                vectTmpXY = vectTmpXY/vectTmpXYNorm
                # compose a list of the only solution
                vectTmp = [np.array([vectTmpXY[0],vectTmpXY[1],0.])]
                # corrected speed of sound (this is the most probable parameter
                # that is in error)
                sndSpdCorr = 1.0/vectTmpXYNorm
            if debug:
                print '2D: in-plane vect = ',vectTmp
            # now we transform the above-calculated unit sighting vector w.r.t.
            # the plane of the sensors to the global coordinate system
            sightVect = [vectTmpI[0]*xAxis+vectTmpI[1]*yAxis+vectTmpI[2]*zAxis \
                for vectTmpI in vectTmp]
        else:
            """ The treatment of a 3-D sensor array:
                1.  Compute the unit sighting vector using standard formulation;
                    this problem may be over-determined if more than 4 sensors
                    are present in the cluster, in which case a least-squares
                    method is used
                2.  If the length of the above vector is other than unity, then,
                    as in the 2D case, we unitize the vector and return the
                    indicated correction factor for the speed of sound
            """
            distVects = np.zeros((nSensors-1,3),dtype=np.float)
            for iSnsr in range(nSensors-1):
                distVects[iSnsr,:] = Sensors[iSnsr+1].coords - Sensors[0].coords
            vectTmp = np.dot(np.linalg.pinv(distVects),tau0)*sndSpd
            # norm of above solution vector            
            vectTmpNorm = np.linalg.norm(vectTmp)
            # since there is no solution ambiguity with a 3D cluster, the
            # solution list is singleton
            sightVect = [vectTmp/vectTmpNorm]
            # corrected speed of sound (this is the most probable parameter
            # that is in error)
            sndSpdCorr = 1.0/vectTmpNorm
            
        return sightVect, clstr.centroid, sndSpdCorr

    #enddef SightVectClstr

#endclass SightVect

def _closestApproach(P1,V1,P2,V2):
    """ A line is defined in 3D by the coordinate array 'L':
            L = P + g*V,
        where 'P' and 'V' are 3-element arrays defining a point on the line and
        a vector parallel to the line, and 'g' is the parameter of the line.
        Let us have two lines as
            L1 = P1 + g*V1,    L2 = P2 + h*V2.
        Then the line segment from L1 to L2 is
            L = L2 - L1 = P2-P1 - g*V1 + h*V2.
        The line joining the points of closest approach of the two lines will be
        the shortest 'L'. Thus, we have to find 'g' and 'h' such that l := ||L||
        is minimized. To avoid square roots, we minimize l**2 instead. Defining
            P12 = P2 - P1
        we have
            l**2 = P12.P12 + V1.V1*g**2 + V2.V2*h**2 - 2*P12.V1*g + 2*P12.V2*h
                    - 2*V1.V2*g*h,
        where ().() indicates dot product of two quantities.
        The first derivative of l**2 w.r.t. 'g' and 'h' must vanish. We have
            d(l**2)/dg = 2*V1.V1*g - 2*P12.V1 - 2*V1.V2*h = 0,
            d(l**2)/dh = 2*V2.V2*h + 2*P12.V2 - 2*V1.V2*g = 0.
        Or,
            A*j = b,
        where
            A := [ [V1.V1, -V1.V2], [-V1.V2, V2.V2] ],  j := [[g],[h]],
            b := [ [P12.V1], [-P12.V2] ].
        Assuming that A is invertible, the solution is simply j = A\b.
        
        OUTPUTS:
            dca - distance of closest approach
            Pc1 - point of closest approach on first line
            Pc2 - point of closest approach on second line
    """
    # formulate the matrix 'A'
    A = np.zeros((2,2))
    A[0,0] = np.dot(V1,V1)
    A[0,1] = - np.dot(V1,V2)
    A[1,0] = A[0,1]
    A[1,1] = np.dot(V2,V2)
    # ensure that system is solvable
    if np.linalg.cond(A) > 1/np.finfo(np.float64).eps:
        warnings.warn('Matrix ill-conditioned; could not invert')
        return None, None, None
    # formulate the vector 'b'
    P12 = P2 - P1
    b = np.array([np.dot(P12,V1), -np.dot(P12,V2)])
    # solve the system
    j = np.linalg.solve(A,b)
    # formulate the return values
    Pc1 = P1 + j[0]*V1
    Pc2 = P2 + j[1]*V2
    dca = np.linalg.norm(Pc1 - Pc2)
    return dca, Pc1, Pc2
#enddef _closestApproach
