#!/usr/bin/python 

#  \brief Driver routine for gunshot localization
#  \author A. Sinha

import math, os
import numpy as np
from matplotlib import pyplot as plt

import tools, locate, sim

dtFctr = 1000

def SolverAnalyzeSim(filename,dataFldr='.'):

    config = sim.Config_GunshotSim(filename)

    dtAct = config.dt
    
    dtUse = dtAct/dtFctr
    
    config.dt = dtUse
    
    snsrD = float(config.snsrD)
    srcR = float(config.srcR)
    srcDTheta = float(config.srcDTheta)

    snsrCentroidalArm = snsrD*math.sin(math.pi/3)*2./3.
    
    snsrCoords = np.zeros((3,3),dtype=np.float)
    for iSnsr in range(3):
        ang = 2.*math.pi/3*iSnsr
        snsrCoords[iSnsr,0] = math.cos(ang)*snsrCentroidalArm
        snsrCoords[iSnsr,1] = math.sin(ang)*snsrCentroidalArm

    np.savetxt(tools.environmentSim.filenameSensLoc,snsrCoords)
    
    nTheta = int(math.floor(180./srcDTheta))+1
    

    iDelayAdd = dtFctr/2

    slvrOptions = {'plot': False,
                   'debug': False,
                   'autoReorder': True}

    thetas = [iTheta*srcDTheta for iTheta in range(nTheta)]


    errBrng = np.zeros((nTheta,4),dtype=np.float)
    errRange = np.zeros((nTheta,4),dtype=np.float)
    IPM = np.array([[1,1,-1,-1],[1,-1,1,-1]],dtype=np.int)
    for ipm in range(4):
        jpm1 = IPM[0,ipm]
        jpm2 = IPM[1,ipm]
        for iTheta in range(nTheta):
            theta = thetas[iTheta]*math.pi/180.
            
            if 'debug' in slvrOptions and slvrOptions['debug']:
                print 'theta = ',thetas[iTheta]
            srcLoc = np.array([math.cos(theta),math.sin(theta),0.])*srcR
    
            env = tools.EnvironmentSim(srcLoc,config,dataFldr=dataFldr)
            env.calcIDelaysAll()
            
            env.Clusters[0].IDelays[0,1] += jpm1*iDelayAdd
            env.Clusters[0].IDelays[0,2] += jpm2*iDelayAdd
            env.Clusters[0].IDelays[1,0] += jpm1*iDelayAdd
            env.Clusters[0].IDelays[1,2] += jpm2*iDelayAdd
            env.Clusters[0].IDelays[2,0] += jpm1*iDelayAdd
            env.Clusters[0].IDelays[2,1] += jpm2*iDelayAdd
        
            slvr = locate.WaveFrontCurveMethod(env)
            slvr.calcSrcLocClstrAvg(slvrOptions)
            
            if not len(slvr.srcLocs):
                errBrng[iTheta,ipm] = np.nan
                errRange[iTheta,ipm] = np.nan
                continue
    
            slvRs = np.array([np.linalg.norm(loc) for loc in slvr.srcLocs])
            
            iLoc = np.argmin(np.abs(slvRs - srcR))
#            iLoc = np.argmax(slvRs)
            
            slvLoc = slvr.srcLocs[iLoc]
            
            slvR = np.linalg.norm(slvLoc)
            slvBrng = math.atan2(slvLoc[1],slvLoc[0])
            if theta > math.pi/2:
                if slvBrng < -math.pi/2:
                    slvBrng += 2*math.pi
            
            errRange[iTheta,ipm] = abs(slvR - srcR)
            errBrng[iTheta,ipm] = abs(slvBrng - theta)


#    np.savetxt(os.path.join(dataFldr,'thetas.txt'),thetas)
#    np.savetxt(os.path.join(dataFldr,'errOptmBrng.txt'),errBrng*180./math.pi)
#    np.savetxt(os.path.join(dataFldr,'errOptmRange.txt'),errRange/srcR)
#    np.savetxt(os.path.join(dataFldr,'errOptmBrngMax.txt'), \
#        np.max(errBrng,axis=1)*180./math.pi)
#    np.savetxt(os.path.join(dataFldr,'errOptmRangeMax.txt'), \
#        np.max(errRange,axis=1)/srcR)

#    errBrngAvg = np.zeros((nTheta),dtype=np.float)
#    errRangeAvg = np.zeros((nTheta),dtype=np.float)
#    for iTheta in range(nTheta):
#        tmp = errBrng[iTheta,:]
#        Tmp = tmp[~np.isnan(tmp)] #remove nan's
#        errBrngAvg[iTheta] = np.average(Tmp)
#        tmp = errRange[iTheta,:]
#        Tmp = tmp[~np.isnan(tmp)] #remove None's
#        errRangeAvg[iTheta] = np.average(Tmp)

    plt.figure()
    plt.subplot(2,1,1)
    for ipm in range(4):
#        plt.semilogy(thetas,errRange[:,ipm]/srcR)
        plt.plot(thetas,errRange[:,ipm]/srcR)
#    plt.semilogy(thetas,errRangeAvg/srcR)
    plt.ylim([0,2])
    plt.subplot(2,1,2)
    for ipm in range(4):
        plt.semilogy(thetas,errBrng[:,ipm]*180./math.pi)
#    plt.semilogy(thetas,errBrngAvg*180./math.pi)
    plt.show()


#    plt.figure()
#    plt.subplot(2,1,1)
##    plt.semilogy(thetas,np.max(errRange,axis=1)/srcR)
#    plt.plot(thetas,np.max(errRange,axis=1)/srcR)
#    plt.subplot(2,1,2)
#    plt.semilogy(thetas,np.max(errBrng,axis=1)*180./math.pi)
#    plt.show()
