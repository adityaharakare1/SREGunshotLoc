#!/usr/bin/python 

#  \brief template class for solving for source location
#  \author A. Sinha

import copy
import numpy as np
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from MyPythonCodes.tools import pltTools

my_eps = 1.e6*np.finfo(np.float64).eps

class SolverTemplate(object):
    """ template class for solving for source location
    
        ATTRIBUTES:
        env:     object of 'Environment' class defining problem
        srcLocs: list of calculated possible source location(s)
        tEvnts:  list of calculated possible event time(s)
        
        METHODS:
        calcSrcLocClstrAvg: calculate most probable solution based on selected
                            average of solutions from each separate cluster;
                            actual implementation of '_calcSrcLocClstr' must be
                            provided by child class for this method to work
        getBestSensorOrder: determines best sensor order to minimize the maximum
                            normalized time-difference-of-arrival at common
                            sensor
        _plotSoln:          plot sensor locations, and source location solution
        _plotSolnsClstr:    plot geometry of a sensor cluster, and corresponding
                            source location solutions
        _plot3dInit:        initiate 3d figure
    """
    def __init__(self,env):
        """ initialization
        
            INPUTS:
            env: object of 'Environment' class defining problem
        """
        self.env = env #register supplied 'Environment' object as attribute
        self.srcLocs = [] #set source locations to empty list for now
        self.tEvnts = []  #set source event instant to empty list for now
    
    def calcSrcLocClstrAvg(self,options):
        """ calculate probable source location(s) based on data recorded on all
            clusters, performing average over results from all clusters.
            If only one cluster of sensors is available, then all possible 
            solutions for source locations are returned since there is no basis
            to choose any one of them.
            However, if more than one cluster of sensors is available, then the
            average of the single most probable solutions for source location is
            returned.
            
            INPUTS:
            options: dict of solver options (booleans are False by default)
                     including (but not limited to) the following keywords
                plot:        plot the results and sensors
                debug:       write out (to standard output) debugging info
        """
        if 'plot' in options and options['plot']:
            self._plot3dInit()

        srcLocs = []
        for iClstr in range(self.env.nClusters): #go thru all clusters in env
            # calculate all possible source location(s) based on data recorded
            # on this cluster
            [srcLocsCurr, error, eta] = self._calcSrcLocClstr(iClstr,options)
            if 'debug' in options and options['debug']:
                print 'calcSrcLoc: iClstr=',iClstr,', srcLocsCurr=',srcLocsCurr
            # separate action for first and remaining clusters
            if iClstr == 0:
                # in case of first (or only) cluster, retain all computed
                # solutions as possible source locations, since no other info
                # is available at present
                srcLocs = srcLocsCurr
            else:
                # in case of subsequent clusters, we can compare the set of all
                # possible solutions from current cluster against the set of
                # previously computed solution(s) to determine the closest
                # (in terms of Euclidean distance) solution in each of set
                nSLPrev = len(srcLocs) #no. of previous solutions
                nSLCurr = len(srcLocsCurr) #no. of current solutions
                # declare array to contain distances between each pair of
                # solutions in the 2 sets
                dists = np.zeros((nSLPrev,nSLCurr),dtype=np.float)
                for iSP in range(nSLPrev): #go thru all previous solution(s)
                    for iSC in range(nSLCurr): #go thru all current solution(s)
                        # calculate Euclidean distance between iSP'th previous
                        # solution and iSC'th current solution
                        dists[iSP,iSC] = np.linalg.norm(srcLocs[iSP] \
                            -srcLocsCurr[iSC])
                # determine minimum distance for each previous solution
                minsPrev = np.amin(dists,axis=1) #length 'nSLPrev' array
                # determine which current solution yields the above minimum
                # for each previous solution
                iMinsCurr = np.argmin(dists,axis=1) #length 'nSLPrev' array
                # determine which previous solution has the minimum distance
                iMinPrev = np.argmin(minsPrev) #scalar
                # determine which current solution has the minimum distance
                iMinCurr = iMinsCurr[iMinPrev] #scalar
                if iClstr == 1:
                    # in case this is the second cluster, update 'srcLocs' to be
                    # the (single) previous solution (from first cluster) that
                    # has the minimum distance to one of the current solutions
                    srcLocs = [srcLocs[iMinPrev]]
                # update 'srcLocs' as average over all previous nearby solutions
                # and the current nearby solution (note that 'srcLocs' contained
                # the average over 'iClstr' probable solutions till now)
                srcLocs = [(srcLocs[0]*iClstr+srcLocsCurr[iMinCurr])/(iClstr+1)]
        # update 'srcLocs' attribute of self with above calculated solution(s)
        self.srcLocs = srcLocs

    #enddef calcSrcLocClstrAvg
    
    def calcBestSrcLocClstr(self,options):
       
        if 'plot' in options and options['plot']:
            self._plot3dInit()

        srcLocs = []
        err = []
        snsr_ref = []
        NoLoc = 0

        for iClstr in range(self.env.nClusters): #go thru all clusters in env
            try:
                [srcLocsCurr, error, snsr_refs] = self._calcSrcLocClstr(iClstr,options)
            except Exception as msg:
                NoLoc += 1
                if 'debug' in options and options['debug']:
                    print msg
                continue
            if 'debug' in options and options['debug']:
                print 'calcSrcLoc: iClstr=',iClstr,', srcLocsCurr=',srcLocsCurr                
            if srcLocsCurr is None or len(srcLocsCurr) == 0:
                NoLoc += 1
                continue
            else:    
                nSol = len(srcLocsCurr)
                dist = np.zeros(nSol)
                for i in range(nSol):
                    dist[i] = np.linalg.norm(srcLocsCurr[i])
                
                i_distmax = np.argmax(dist)     
                srcLocs.append(srcLocsCurr[i_distmax])
                err.append(error[i_distmax])
                snsr_ref.append(snsr_refs[i_distmax])

        if len(err) == 0: #No cluster worked
            self.snsr_ref = 0
            self.srcLocs = None
            return

        # Execution comes here if at least one cluster worked
        i_min = np.argmin(err)
        srcLocs = srcLocs[i_min]
        self.snsr_ref = snsr_ref[i_min]
        self.srcLocs = srcLocs

    #enddef calcBestSrcLocClstr
    
    def calcBestRefSnsr(self,options):         
        snsrOrder = [0, 1, 2, 3]
        snsrOrder = self.getBestSensorOrder(0, snsrOrder)
        self.snsr_ref1 = snsrOrder[0]        
    #enddef calcBestRefSnsr
    
    def _calcSrcLocClstr(self,options):
        """ dummy function; should be implemented in child class """
        raise Exception('Should be coded by child class')
        
    def getBestSensorOrder(self,iClstr,snsrIdsIn=None):
        """ Time-difference-of-arrival (TDOA) of an event signature at a sensor
            pair is often used in localization.
            TDOA is normalized by multiplying by speed of sound and dividing by
            the distance between the sensor pair; we denote this by 'eta'.
            Analysis shows that high absolute values of normalized TDOA lead to
            high inaccuracy in localization.
            Here, we choose a single common sensor for all the sensor pairs in
            a cluster, such that it has the least maximum normalized TDOA.
            
            INPUTS:
            iClstr:    cluster index in environment
            snsrIdsIn: list of sensor indices in cluster to consider (not all
                       sensors in the cluster need be used); None implies all
            
            OUTPUTS:
            snsrOrder: list of sensor indices in cluster led by common sensor
                       chosen per the criterion discussed above
        """
        clstr = self.env.Clusters[iClstr] #retrieve 'Cluster' object
        sndSpd = self.env.config.sndSpd   #speed of sound
        # 'snsrIds' is list of sensors indices in cluster to consider
        if snsrIdsIn is None:
            snsrIds = range(clstr.nSensors) #consider all
        else:
            snsrIds = snsrIdsIn #consider the 'snsrIdsIn' list supplied as input
        # convert 'snsrIds' list to list of singleton lists, as required later
        snsrIdsLL = [[ii] for ii in snsrIds]
        # make a copy of square matrix of inter-sensor distances
        Dists = copy.deepcopy(clstr.Dists)
        # diagonal of 'Dists' is zeros; fill them by 1's to avoid division-by-0
        np.fill_diagonal(Dists, 1.)
        # normalized time delays (square matrix for all possible sensor pairs)
        # among the sensor indices desired (may not be all present in cluster)
        etas = clstr.Delays[snsrIdsLL,snsrIds]*sndSpd \
            /Dists[snsrIdsLL,snsrIds]
        # indices of maxima along each column of 'etas' -- ith entry gives the
        # index 'j' of the sensor that yields the highest absolute 'eta' with
        # the 'i' sensor
        iMaxes = np.argmax(np.abs(etas), axis=1)
        # values of etas in the maxima retrieved above (one for each sensor)
        maxEtas = np.array([etas[iSnsrRef,iMaxes[iSnsrRef]] \
            for iSnsrRef in range(len(iMaxes))])
        # sensor index that has the minimum value of the maximum absolute 'eta';
        # this is going to be the chosen common sensor
        iSnsrRef = np.argmin(np.abs(maxEtas))
        # pre-allocate list to be returned
        snsrOrder = np.zeros((len(snsrIds)),dtype=np.int)
        # first element is the chosen common sensor
        snsrOrder[0] = snsrIds[iSnsrRef]
        # other elements are indices of sensors remaining in 'snsrIds'
        snsrOrder[1:] = np.setdiff1d(snsrIds,snsrOrder[0])
        return snsrOrder

    #enddef getBestSensorOrder

    def _plotSoln(self):
        """ plot sensor locations, and source location solution
        """
        ax = self._plot3dInit()
        xs = []; ys = []; zs = [] #sensor coordinates' lists
        for Clstr in self.env.Clusters: #go thru all clusters in env
            for Snsr in Clstr.Sensors: #go thru all sensors in cluster
                xs.append(Snsr.coords[0])
                ys.append(Snsr.coords[1])
                zs.append(Snsr.coords[2])
        ax.scatter(xs,ys,zs,c='k',marker='x') #plot sensor markers
        ax.hold('on')
        # plot source location solutions
        for srcLoc in self.srcLocs:
            ax.scatter(srcLoc[0],srcLoc[1],srcLoc[2],c='r',marker='^')
        pltTools.set_aspect_equal_3d(ax) #axis equal
        plt.show()
    #enddef _plotSoln

    def _plotSolnsClstr(self,iClstr,srcLocs,snsrOrderIn=None):
        """ plot geometry of a sensor cluster, and corresponding source location
            solutions
            
            INPUTS:
            iClstr:      cluster index in environment
            srcLocs:     list of solutions for source location
            snsrOrderIn: list of sensor indices in cluster to plot (not all
                         sensors in the cluster need be used); None implies all
        """
        clstr = self.env.Clusters[iClstr] #retrieve 'Cluster' object
        if snsrOrderIn is None:
            snsrOrder = range(clstr.nSensors)
        else:
            snsrOrder = snsrOrderIn
        # x-, y- and z-coordinates of sensors
        plt_x = np.array([clstr.Sensors[i].coords[0] for i in snsrOrder])
        plt_y = np.array([clstr.Sensors[i].coords[1] for i in snsrOrder])
        plt_z = np.array([clstr.Sensors[i].coords[2] for i in snsrOrder])
        # retrieve axis handle
        ax = plt.gca()
        # plot common sensor
        ax.scatter(plt_x[0],plt_y[0],plt_z[0],c='r',marker='o')
        for iSnsrTo in range(1,len(plt_x)): #go thru remaining sensors
            # plot arms of cluster from common sensor (sensor 0)
            ax.plot(plt_x[[0,iSnsrTo]],plt_y[[0,iSnsrTo]],plt_z[[0,iSnsrTo]],'k')
            # plot non-common sensors
            ax.scatter(plt_x[iSnsrTo],plt_y[iSnsrTo],plt_z[iSnsrTo],c='b', \
                marker='x')
        # plot source location solutions
        for iSL in range(len(srcLocs)):
            ax.scatter(srcLocs[iSL][0],srcLocs[iSL][1],srcLocs[iSL][2],c='g', \
                marker='p')
        pltTools.set_aspect_equal_3d(ax) #axis equal
        plt.show()

    #enddef _plotSolnsClstr

    def _plot3dInit(self):
        """ initiate 3d figure """
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d') #3d plot setup
        return ax

#endclass SolverTemplate
