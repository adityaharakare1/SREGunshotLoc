#!/usr/bin/python

## \file eventCategorize.py
#  \brief Categorizes an event detected in an acoustic signal
#  \author A. Sinha

import math, os
import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt
#from matplotlib import cm as cm
#from matplotlib.backends.backend_pdf import PdfPages
#from PyPDF2 import PdfFileReader, PdfFileWriter

from MyPythonCodes.tools import redirect

from tools import Environment, dataAccess

#_TBefr = 0.0002 #Window left end w.r.t. peak (sec)
#_TAftr = 0.001 #Window right end w.r.t. peak (sec)
_SW_Min_Neg_Peak = 0.5 #Minimum magnitude of -ve peak (wrt +ve) for N-wave trial

# Categories into which events are classified
_EventCategories = {
    'MuzzleBlast' : 0,
    'ShockWave'   : 1}
'''
_fgCategorize = 'EventCategories.pdf'
_fnCategorize = 'EventCategories.txt'
_fnFitErrors = 'EventFitErrors.txt'

""" Categorize all (previously detected and segragated) events across a project
    (as defined in the 'dataAccess' module)

    INPUTS:
    projPath : path to project folder (default: pwd)
    options  : dict of behaviour options (booleans are False by default)
        plot : plot the data in each sensor, and show the fits?
"""
def EventCategorizeProj(projPath='.',options=None):
    # Determine whether to plot results based on 'options' (default is False)
    if options is not None and 'plot' in options and options['plot']:
        plot = True
        pwProj = PdfFileWriter() #Page-accumulator of project-level pdf
    else:
        plot = False
    # Retrieve the folder structure of the project
    proj = dataAccess.DataAccess(projPath=projPath);    proj.getFldrStruct()
    categoriesProj = [] #List of categories of all events in all sub-folders
    for fldrTuple in proj.fldrStruct: #Go thru each sub-folder of the project
        subFldr = fldrTuple[0] #sub-folder name
        print 'Processing '+subFldr
        if plot:
            pwSub = PdfFileWriter() #Page-accumulator of sub-folder-level pdf
        categoriesSub = [] #List of categories of all events in sub-folder
        categoriesSubProj = [] #Same as above, but with more descriptive strings
        for evntFldrTpl in fldrTuple[1]: #Go thru each event
            evntFldr = evntFldrTpl[0] #Name of event folder
            # Full path to event folder (absolute or from current directory)
            evntFldrFull = os.path.join(projPath,subFldr,evntFldr)
            # Instantiate event categorization class, using the default config
            # filename
            categorize = EventCategorize(dataFldr=evntFldrFull)
            # Perform the actual categorization
            category = categorize.categorize(options={'plot':plot})
            minF = np.min(categorize.errors[:,0]) #min error in Friedlander fits
            minN = np.min(categorize.errors[:,1]) #min error in N-wave fits
            # Append determined category and min errors to sub-folder's list
            categoriesSub.append(evntFldr+': '+str(category)+' [ '+str(minF) \
                +' '+str(minN)+' ]')
            categoriesSubProj.append(subFldr+os.path.sep+categoriesSub[-1])
            if plot:
                # Categorization results have been plotted and available in a
                # pdf file in the event sub-sub-folder; read it and append the
                # (sole) page to both the sub-folder level and project level
                # accumulated pdfs; unfortunately, due to a possible bug in the
                # PdfFileReader or PageObject, the page has to be read twice
                pdfFnFull = os.path.join(evntFldrFull,_fgCategorize)
                pg1 = PdfFileReader(pdfFnFull).getPage(0)
                pwSub.addPage(pg1)
                pg2 = PdfFileReader(pdfFnFull).getPage(0)
                pwProj.addPage(pg2)
        #endfor evntFldrTpl in fldrTuple[1]
        # Concatenate sub-folders' categories list to running list of project
        categoriesProj += categoriesSubProj
        # Write out the categories of all events in sub-folder
        with open(os.path.join(projPath,subFldr,_fnCategorize),'w') as f:
            for category in categoriesSub:
                f.write("%s\n" % category)
        if plot:
            # Write out all accumulated events' pdf pages in sub-folder
            with open(os.path.join(projPath,subFldr,_fgCategorize),'wb') as f:
                pwSub.write(f)
    #endfor fldrTuple in proj.fldrStruct
    # Write out the categories of all events in all sub-folders of the project
    with open(os.path.join(projPath,_fnCategorize),'w') as f:
        for category in categoriesProj:
            f.write("%s\n" % category)
    if plot:
        # Write out all accumulated events' pdf pages in project
        with open(os.path.join(projPath,_fgCategorize),'wb') as f:
            pwProj.write(f)
#enddef EventCategorizeProj
'''

class EventCategorize(object):
    """ obj = EventCategorize(configIn,dataFldr)
        
        Class for categorizing a previously detected and segregated 'event'
        recorded by all sensors (across clusters)

        ATTRIBUTES:
        dataFldr : path to data folder (default: pwd)
        config   : configuration object, or filename of same
        env      : object of 'Environment' class defining the problem, with a
                   single event already detected and segragated
        errors   : 2D array of fitting errors for the event recorded on all the
                   sensors, with categories along rows and sensors along columns
        category : the determined category of the event
        
        METHODS:
        categorize : actual categorization of event
    """    

    def __init__(self,data,configIn=None):
        """ initialization
        
            INPUTS:
            configIn:  configuration object, or filename of same (None defaults
                       filename to standard configuration info filename)
            dataFldr : path to data folder (default: pwd)
        """
        self.data = data
        self.config = configIn
        self.env = None
        self.errors = None
        self.category = -1

    def categorize(self,options=None):
        """ Categorize a previously detected and segregated 'event' recorded by
            all sensors (across clusters)
        
            ACTIONS:
            1.  Retrieves data recorded on sensors that is truncated to contain
                a single event
            2.  Fit a Friedlander profile and an N-wave profile to the data of
                each sensor, and determine the residual mean-square errors.
            3.  Categorize the event based on the minimum error observed across
                all sensors (muzzle blast if the Friedlander fit gives the least
                error, and shock wave if the N-wave fit is the best).
                
            INPUTS:
            options: dict of classifier options (booleans are False by default)
                plot: plot the data in each sensor, and show the fits
            
            OUTPUTS:
            category : The category (class) of the event (appropriate value of
                       the _EventCategories dict)
        """
        if options is not None and 'plot' in options and options['plot']:
            plot = True
            fig = plt.figure()          #Open figure for plotting
            cmap = cm.get_cmap('jet')   #Retrieve colormap
        else:
            plot = False
            fig = None
        # Instantiate the 'environment' and retrieve all the data for the event
#        with redirect.folder(self.dataFldr):
        self.env = Environment(self.data, self.config)
        self.env.rtrvData()
        nSensors = self.env.nSensors
        self.errors = np.ones((nSensors,2))*np.inf #initialize to +ve infinity
        dt = self.env.dt #Sampling period
        iSnsr = 0
        for clstr in self.env.Clusters:
            for snsr in clstr.Sensors: #Go thru each sensor
                imax = np.argmax(snsr.data) #Index of +ve peak of signal
                # Determine left and right end indices (relative to 'imax') to
                # window data (already windowed) based on '_TBefr' & '_TAftr'
                #ileft = max([imax - int(math.ceil(_TBefr/dt)),0])
                ileft = 0
                #iright = min([imax + int(math.ceil(_TAftr/dt)),len(snsr.data)])
                iright = len(snsr.data)
                data = snsr.data[ileft:iright] #Extract chosen window of data
                data /= np.max(data) #Normalize by max
                # Create time axis such that peak occurs at t=0
                tAxis = (np.arange(iright - ileft)-(imax-ileft))*dt
                fitErrF = False #As yet, no error encountered in Friedlander fit
                fitErrN = False #As yet, no error encountered in N-wave fit
                # Generate initial guesses for various fit parameters
                jmax = np.argmax(data) #Index of +ve peak of 'data'
                # Guess time to first 0-crossing working backward from +ve peak,
                # which is the rise time of the signal
                jzeroCrossMinus = np.argmax(data[jmax::-1] < 0)
                if jzeroCrossMinus == 0: #No 0-crossing found in above
                    t_Rise0 = -tAxis[0] #Guess rise time is -ve of left time end
                else:
                    t_Rise0 = -tAxis[jmax-jzeroCrossMinus] #Estimate rise time
                try: #Fitting Friedlander profile
                    # Guess the time to first 0-crossing after +ve peak, which
                    # is the decay time of the signal
                    jzeroCrossPlus = np.argmax(data[jmax:] < 0)
                    if jzeroCrossPlus == 0: #No 0-crossings found in above
                        MB_t_Decay0 = tAxis[-1]
                    else:
                        MB_t_Decay0 = tAxis[jmax+jzeroCrossPlus]
                    # Guess time from the +ve peak to the -ve peak of the signal
                    jmin = np.argmin(data[jmax:])
                    MB_t_Trough0 = tAxis[jmax+jmin]
                    if MB_t_Trough0 <= MB_t_Decay0: #Can happen if no -ve swing
                        MB_t_Trough0 = MB_t_Decay0*2 #Guess when -ve peak occurs
                    # Curve fitting of sensor data using Friedlander function
                    optF, covF = curve_fit(Friedlander,tAxis,data, \
                        p0=[t_Rise0,MB_t_Decay0,MB_t_Trough0])
                except:
                    fitErrF = True #Failure to fit
                else:
                    # Successful fitting: calculate mean square error of fit
                    FrFitData = Friedlander(tAxis,optF[0],optF[1],optF[2])
                    self.errors[iSnsr,0] = np.average(np.square(data-FrFitData))
                if np.min(data[jmax:])<-_SW_Min_Neg_Peak: #N-wave fit attempt?
                    # (Normalized) -ve peak should be of sufficient magnitude to
                    # warrant an attempt to fit an N-wave profile to the signal
                    try: #Fitting N-wave profile
                        # Guess the time from the +ve peak to the -ve peak
                        jmin = np.argmin(data)
                        SW_t_Decay0 = tAxis[jmin]
                        # Curve fitting of sensor data using N-wave function
                        optN, covN = curve_fit(NWave,tAxis,data, \
                            p0=[t_Rise0,SW_t_Decay0])
                    except:
                        fitErrN = True #Failure to fit
                    else:
                        # Successful fitting: calculate mean square error of fit
                        NWFitData = NWave(tAxis,optN[0],optN[1])
                        self.errors[iSnsr,1] = np.average(np.square(data \
                            -NWFitData))
                else:
                    fitErrN = True #Didn't even attempt an N-wave fit; => error            
                if plot:
                    rgba = cmap(float(iSnsr)/nSensors) #this sensor's plot color
                    plt.plot(tAxis,data,color=rgba[:3]) #plot the sensor data
                    plt.hold('on')
                    if not fitErrF: #No error in Friedlander fit; plot it
                        plt.plot(tAxis,FrFitData,'-.',color=rgba[:3])
                    if not fitErrN: #No error in N-wave fit; plot it
                        plt.plot(tAxis,NWFitData,'--',color=rgba[:3])
                iSnsr += 1
            #endfor snsr in clstr.Sensors
        #endfor clstr in self.env.Clusters
        minF = np.min(self.errors[:,0]) #min error in Friedlander fits
        minN = np.min(self.errors[:,1]) #min error in N-wave fits
        if minF != float('inf') or minN != float('inf'): #At least one is finite
            if minF < minN: #Friedlander fit was best across all sensors
                self.category = _EventCategories['MuzzleBlast'] #Assign category
            else: #N-wave fit was best across all sensors
                self.category = _EventCategories['ShockWave'] #Assign category
        else:
            # If both minima are inf (i.e. foregoing fits are all erroneous),
            # then category should be default
            self.category = -1

#        with redirect.folder(self.dataFldr):
            # Write category in text files (overwrite old file, if any)
#            with open(_fnCategorize,'w') as fcls:
#                fcls.write(str(self.category)+'\n')
            # Write fit-errors in text files (overwrite old file, if any)
#            with open(_fnFitErrors,'w') as ffer:
#                np.savetxt(ffer,self.errors)
#            if plot:
                # Save plot in pdf, and close it
#                plt.title(self.dataFldr+': Category '+str(self.category))
#                ppEvent = PdfPages(_fgCategorize)
#                ppEvent.savefig(fig)
#                ppEvent.close()
#                plt.close()

        return self.category
    #enddef categorize
'''
    def retrieve(self):
        """ Retrieve category of an event, as determined previously (along with
            any other relevant metadata)
        
            ACTIONS:
            1.  Retrieve the category (integer) from the appropriate stored text
                file in the event folder; if this is unavailable, then run the
                'categorize' method
            2.  Also retrieve the fit errors from the appropriate stored text
                file in the same folder; this should always be available since
                'ACTION 1' above is just concluded; however, as a fail-safe, run
                the 'categorize' method if the text file is unavailable
                
            INPUTS:
            None
            
            OUTPUTS:
            None
        """
        try:
            with open(os.path.join(self.dataFldr,_fnCategorize),'r') as fcls:
                self.category = int(fcls.readline())
        except:
            self.categorize()
        try:
            with open(os.path.join(self.dataFldr,_fnFitErrors),'r') as ffer:
                self.errors = np.loadtxt(ffer)
        except:
            self.categorize()
    #enddef retrieve
'''
#endclass EventCategorize


""" Friedlander profile, as functional form of muzzle blast signatures:
        = 0,                                                      tCntr < -tRise
    F(t)= A(1+tCntr/tRise),                             -tRise <= tCntr < 0
        = A(1-tCntr/tDecay)*exp(-tCntr/(tTrough-tDecay)),    0 <= tCntr
    tCntr = t - tPeak.
    
    Essentially, this has a linear rise from 0 to A, followed by a decay and an
    undershoot. The rise is over 'tRise', the decay to zero is over 'tDecay',
    and the minimum occurs at 'tTrough' past the peak time.
    
    ASSUMPTIONS:
    The signal is assumed to have been normalized and centered such that the
    peak is of unit amplitude and occurs at t = 0 (tPeak = 0, A = 1). To reduce
    the burden on optimization, we do not vary these parameters.
    
    INPUT:
    t       : time (possibly a 1D array, or a scalar)
    tRise   : time period over which initial rise occurs from 0 to the peak
    tDecay  : time period over which signal decays to 0 from peak
    tTrough : time period after peak time at which signal attains minimum
    
    OUTPUT:
    PF : Friedlander wave signal
"""
def Friedlander(t,tRise,tDecay,tTrough):
    tPeak=0.
    Amp=1.
    PF = np.zeros_like(t)
    tCntr = t - tPeak
    itRise = np.where((-tRise <= tCntr) & (tCntr < 0))[0]
    if len(itRise):
        PF[itRise] = Amp*(1.+tCntr[itRise]/tRise)
    itDecay = np.where(tCntr >= 0)[0]
    PF[itDecay] = Amp*(1 - tCntr[itDecay]/tDecay) \
        *np.exp(-tCntr[itDecay]/(tTrough-tDecay))
    if len(t) == 1:
        PF = PF[0]
    return PF
#enddef Friedlander


""" N-wave profile, as functional form of shock-wave signatures:
        = 0,                                           tCntr < -tRise
        = A*(1+tCntr/tRise),                 -tRise <= tCntr < 0
    F(t)= A*(1-2*tCntr/tDecay),                   0 <= tCntr < tDecay
        = A*(tCntr-tDecay-tRise)/tRise,      tDecay <= tCntr < tDecay+tRise
        = 0,                           tDecay+tRise <= tCntr 
    tCntr = t - tPeak.
    
    Essentially, this has a linear rise from 0 to A over time 'tRise', followed
    by a linear decay to -A over time 'tDecay', followed by a linear rise back
    to 0 over time 'tRise' again.
    
    ASSUMPTIONS:
    The signal is assumed to have been normalized and centered such that the
    peak is of unit amplitude and occurs at t = 0 (tPeak = 0, A = 1). To reduce
    the burden on optimization, we do not vary these parameters.
    
    INPUT:
    t       : time (possibly a 1D array, or a scalar)
    tRise   : time period over which initial rise occurs from 0 to the peak
    tDecay  : time period over which signal decays to -ve peak from +ve peak
    
    OUTPUT:
    PS : N-wave wave signal
"""
def NWave(t,tRise,tDecay):
    tPeak=0.
    Amp=1.
    PS = np.zeros_like(t)
    tCntr = t - tPeak
    itRise1 = np.where((-tRise <= tCntr) & (tCntr < 0))[0]
    PS[itRise1] = Amp*(1.+tCntr[itRise1]/tRise)
    itDecay = np.where((0 <= tCntr) & (tCntr < tDecay))[0]
    PS[itDecay] = Amp*(1 - 2*tCntr[itDecay]/tDecay)
    itRise2 = np.where((tDecay <= tCntr) & (tCntr < tDecay+tRise))[0]
    PS[itRise2] = Amp*(tCntr[itRise2]-tDecay-tRise)/tRise
    return PS
#enddef NWave
