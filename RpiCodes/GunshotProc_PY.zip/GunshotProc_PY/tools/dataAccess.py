#!/usr/bin/python 

#  \brief accessing (& assistance in creating) data of acoustic event experiment
#  \author A. Sinha

import os, glob, warnings, csv
import numpy as np
from matplotlib import pyplot as plt

from MyPythonCodes.tools import redirect, misc_utils

from . import Environment

skipLogHeader = 1
skip_flds = ['Sample','Time']
configFname = 'config.cfg'      
logFname = 'logbook.csv'
evntFldrPrfx = 'Event'

class DataAccess(object):
    """ class for accessing (and assistance in creating) data of a gunshot
        experiment project
        
        ASSUMPTIONS:
        1.  In an experiment (project), the sensors won't change location or
            organization (into clusters); all such data is present in a project
            folder that also contains a text file with the sensors' positions
        2.  Several separate datasets would have been saved in the experiments,
            possibly for each separate gunshot origin, or even for each separate
            gunshot; the project data is also separated into sub-folders, one
            for each such dataset
        3.  Within each sub-folder, there are sub-sub-folders - one for each
            event detected in the dataset of the parent sub-folder; they will be
            numbered in sequence. Although all the events need not be from the
            same source, this will be the default. These folders will contain
            the actual acoustic signals, as well as any other metadata desired.
        3a. One of the metadata files is the configuration, whose filename must
            be the standard one 'configFname'
        4.  In case of controlled experiments, a log file may be present in the
            project folder that will indicate the acoustic event origin
            corresponding to the datasets in each sub-folder
        5.  Thus, the typical organization of the project folder is as follows:
                project_folder
                |-- dataset sub-folder A (arbitrary name format)
                |   |-- event sub-sub-folder 0 (named evntFldrPrfx+'0')
                |   |-- event sub-sub-folder 1 (named evntFldrPrfx+'1')
                |-- dataset sub-folder B (arbitrary name format)
                |   |-- event sub-sub-folder 0 (named evntFldrPrfx+'0')
                |-- sensor locations file (name format given in environment)
                |-- log file (optional) (named logFname)

        ATTRIBUTES:
        projPath:   path to project folder
        log:        log info of source locations for datasets in project
        fldrStruct: folder structure in project

        METHODS:
        getFldrStruct: get folder structure in project
        nextEvntFldr:  compose name of next-available event folder in a dataset
        chkPltDat:     check data in project by plotting acoustic signals
        readLog:       read the log file
    """
    
    def __init__(self,projPath='.'):
        """ initialization
        
            INPUTS:
            projPath:  path to project folder (default: current working folder)
        """
        self.projPath = projPath #add input as attribute to self
        self.log = None          #set to 'None' since it's not recovered yet
        self.fldrStruct = []     #folder structure is unknown at this point

    def getFldrStruct(self):
        """ get folder structure in project
        
            ACTIONS:
            a)  self.fldrStruct is created as a list of 2-tuples.
            b)  In each 2-tuple
                i)  the first item of the 2-tuple is the dataset folder name
                ii) the second item of the 2-tuple is a list with as many
                    entries as there are separate events; each item is a 2-tuple
                    ->  with first entry being event folder name, and 
                    ->  second entry being event number (retrieved from above,
                        knowing the pattern of event folder names)
        """
        self.fldrStruct = [] #initialize empty list
        with redirect.folder(self.projPath): #get into project folder
            for fldr in sorted(os.listdir('.')): #get all files/folders
                if not os.path.isdir(fldr): #skip if this is not a folder
                    continue
                with redirect.folder(os.path.basename(fldr)): #into sub-folder
                    evntFldrs = [] #initialize empty list: event sub-sub-folders
                    for evntFldr in sorted(glob.glob(evntFldrPrfx+'*')):
                        if not os.path.isdir(evntFldr): #skip if not folder
                            continue
                        # retrieve event number from its name
                        eventNo = int(evntFldr.replace(evntFldrPrfx,""))
                        # append current sub-sub-folder name and number together
                        # as a 2-tuple to list of event folders in current
                        # sub-folder
                        evntFldrs.append((os.path.basename(evntFldr),eventNo))
                # append tuple of current sub-folder name and list of event
                # sub-sub-folders' to folder structure list
                self.fldrStruct.append((fldr,evntFldrs))
        
    def nextEvntFldr(self,subFldr):
        """ compose name of next-available event folder, whose format is
                evntFldrPrfx+str(Event_number)
            
            INPUTS:
            subFldr: sub-folder of a dataset under which event folder is sought
            
            OUTPUTS:
            evntFldrName: name of next-available event folder
        """
        return misc_utils.nextFile(evntFldrPrfx,isdir=True, \
            parent=os.path.join(self.projPath,subFldr))

    def chkPltDat(self):
        """ check data in project by plotting acoustic signals; done by flashing
            each event's data to user one by one, and waiting for user input to
            continue to the next one
        """
        if not self.fldrStruct: #folder structure list is empty at this point
            self.getFldrStruct() #get folder structure in project
        for fldrTuple in self.fldrStruct: #run thru each dataset (sub-folder)
            fldr = fldrTuple[0] #sub-folder name
            for evntFldrInfo in fldrTuple[1]: #go thru each event (sub-sub-folder)
                evntFldr = evntFldrInfo[0] #get event folder name
                with redirect.folder(os.path.join(self.projPath,fldr,evntFldr)):
                    # create environment object (config file name is standard)
                    env = Environment(configFname)
                    env.rtrvData() #retrieve data for event in environment 
                fig = plt.figure() #start figure
                for clstr in env.Clusters: #go thru all clusters
                    for snsr in clstr.Sensors: #go thru all sensors
                        # plot the data of this sensor, with proper location of
                        # samples
                        plt.plot(range(snsr.smplIni,snsr.smplFin+1),snsr.data)
                plt.title(os.path.join(fldr,evntFldr)) #add title
                # wait for use input before closing figure
                plt.draw()
                plt.pause(0.00001)
                raw_input("Press the <ENTER> key to continue...")
                plt.close(fig)

    def readLog(self):
        """ Read log file
            
            ASSUMPTIONS:
            1.  Each row (barring header) in log file has format
                    Folder_Name,x_coord,y_coord,z_coord,EventNo(optional)
            2.  Each row refers to data recorded corresponding to a source
                located at the given coordinates; such data is to be found in a
                folder with the given name
            3.  Individual events in a dataset folder may have different source
                locations in which case the event number will be the 5th column.
                By default, all events in a dataset are assumed to be due to the
                same source location; this is indicated by either no entry or a
                negative entry in the 5th column.
            3.  Saves retrieved info to 'log' attribute of self
            
            ACTIONS:
            a)  self.log is created as a list of 2-tuples.
            b)  In each 2-tuple item
                i)  the first item of the 2-tuple is the dataset folder name
                ii) the second item of the 2-tuple is a dict with
                    ->  key being event numbers (int converted to string), and
                    ->  corresponding value being 3-element numpy 1D array of
                        source coordinates
                    ->  if all events have the same source, then the dict will
                        have only key, viz. 'ALL', the value being as above
        """
        # retrieve log file in project folder (standard name)
        logFiles = glob.glob(os.path.join(self.projPath,logFname))
        if len(logFiles) <> 1:
            warnings.warn('No unique '+logFname+' in '+self.projPath)
            return
        # start empty containers for folder names and source coordinates
        self.log = []
        with open(logFiles[0], 'r') as csvfile:
            csvRdr = csv.reader(csvfile,delimiter=',') #CSV file reader object
            for iHdr in range(skipLogHeader): #skip header lines in log file
                next(csvRdr,None)
            for row in csvRdr: #read remaining rows
                fldr = row[0]
                srcCoords = np.array([float(coord) for coord in row[1:4]])
                if len(row) > 4:
                    eventNo = int(row[4])
                else:
                    eventNo = -1
                fldrsAll = [x[0] for x in self.log] #folders registered till now
                iFldr = [i for i,x in enumerate(fldrsAll) if fldr==x]
                if len(iFldr) == 0:
                    if eventNo < 0:
                        # register source coordinates for all events in folder
                        self.log.append((fldr,{'ALL':srcCoords}))
                    else:
                        # register source coordinates for this event in folder
                        self.log.append((fldr,{str(eventNo):srcCoords}))
                elif len(iFldr) == 1:
                    if eventNo < 0:
                        # trying to register source coordinates for all events,
                        # but source coordinates have been registered for at
                        # least one event in this folder
                        raise Exception(','.join(row)+': duplicate fldr')
                    else: #(possibly partial) info already registered for folder
                        if 'ALL' in self.log[iFldr[0]][1]:
                            # trying to register source coordinates for one
                            # event, but source coordinates have already been
                            # registered for all events in this folder
                            raise Exception(','.join(row)+': fldr is ''ALL''')
                        elif str(eventNo) in self.log[iFldr[0]][1]:
                            # trying to register source coordinates for one
                            # event, but source coordinates have already been
                            # registered for this event in this folder
                            raise Exception(','.join(row)+': event registered')
                        # okay to register this event's source coordinates
                        self.log[iFldr[0]][1][str(eventNo)] = srcCoords
                else:
                    raise Exception('fldrsAll should not have duplication')

    #enddef readLog

#endclass DataAccess
