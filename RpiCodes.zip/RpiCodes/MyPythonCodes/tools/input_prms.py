#!/usr/bin/env python

## \file config.py
#  \brief read & interpret generic configuration file and write same to file
#  \author A. Sinha (starting from SU2v4.0.0/SU2_PY/SU2/io/config.py)

# ----------------------------------------------------------------------
#  Imports
# ----------------------------------------------------------------------

import os, sys, shutil, copy
from . import ordered_bunch

try:
    from collections import OrderedDict
except ImportError:
    from . import OrderedDict

# ----------------------------------------------------------------------
#  Configuration Class
# ----------------------------------------------------------------------
class Params(ordered_bunch):
    def __init__(self, *args, **kwargs):
        
        # look for filename in inputs
        if args and isinstance(args[0],str):
            filename = args[0]
            args = args[1:]
        elif kwargs.has_key('filename'):
            filename = kwargs['filename']
            del kwargs['filename']
        else:
            filename = ''
        
        # initialize ordered bunch
        super(Params,self).__init__(*args,**kwargs)

        # Declare empty lists for various parameters requiring extra handling
        self.prms = {} #Empty dict
        # comma delimited lists of strings with or without parentheses
        self.prms['liststring'] = [] 
        # comma delimited lists of int
        self.prms['listint'] = []
        # comma delimited lists of floats
        self.prms['listfloat'] = []
        # int parameters
        self.prms['int'] = []
        # float parameters
        self.prms['float'] = []
        # external functions
        self.prms['fnc'] = {} #Empty dictionary, NOT list
        
        # read config if it exists
        if filename:
            try:
                self.read(filename)
            except IOError:
                print 'Could not find config file: %s' % filename
	    except:
		print 'Unexpected error: ',sys.exc_info()[0]
		raise
    
    def read(self,filename):
        """ reads from a config file """
        konfig = read_config(filename,self.prms)
        self.update(konfig)
    
    def insert_prm(self,keyword,vartype,fnc_rd=[],fnc_wrt=[]):
        """  insert name of parameter requiring extra handling """
        if vartype.lower() == 'liststring':
            self.prms['liststring'].append(keyword)
        elif vartype.lower() == 'listint':
            self.prms['listint'].append(keyword)
        elif vartype.lower() == 'listfloat':
            self.prms['listfloat'].append(keyword)
        elif vartype.lower() == 'int':
            self.prms['int'].append(keyword)
        elif vartype.lower() == 'float':
            self.prms['float'].append(keyword)
        elif vartype.lower() == 'fnc':
            self.prms['fnc'][keyword] = {}
            self.prms['fnc'][keyword]['read'] = fnc_rd
            self.prms['fnc'][keyword]['write'] = fnc_wrt
    
    def __getattr__(self,k):
        try:
            return super(Params,self).__getattr__(k)
        except AttributeError:
            raise AttributeError , 'Params parameter not found'
        
    def __getitem__(self,k):
        try:
            return super(Params,self).__getitem__(k)
        except KeyError:
            raise KeyError , 'Params parameter not found: %s' % k
    
    def __repr__(self):
        #return '<Params> %s' % self._filename
        return self.__str__()
    
    def __str__(self):
        output = 'Params: %s' % self._filename
        for k,v in self.iteritems():
            output +=  '\n    %s= %s' % (k,v)
        return output

#    def __setitem__(self, key, item): 
#        self.__dict__[key] = item
#
#    def __getitem__(self, key): 
#        return self.__dict__[key]
#
#    def __repr__(self): 
#        return repr(self.__dict__)

    def write(self,filename=''):
        """ updates an existing config file """
        if not filename: filename = self._filename
        assert os.path.exists(filename) , 'must write over an existing config file'
        write_config(filename,self)
        
    def dump(self,filename=''):
        """ dumps all items in the config bunch, without comments """
        if not filename: filename = self._filename
        dump_config(filename,self)

##: class Params


# ------------------------------------------------------------------------------
#  Read configuration parameters
# ------------------------------------------------------------------------------

def read_config(filename,prms):
    """ reads a config file """
      
    # initialize output dictionary
    data_dict = OrderedDict()

    input_file = open(filename)
    
    # process each line
    while 1:
        # read the line
        line = input_file.readline()
        if not line:
            break
        
        # remove line returns
        line = line.strip('\r\n')
        # make sure it has useful data
        if (not "=" in line) or (line[0] == '%'):
            continue
        # split across equals sign
        line = line.split("=",1)
        this_param = line[0].strip()
        this_value = line[1].strip()
        
        assert not data_dict.has_key(this_param) , \
            ('Params file has multiple specifications of %s' % this_param )

        """ handle parameter types """
        
        # comma delimited lists of strings with or without paren's
        if (this_param in prms['liststring']):
            # remove white space
            this_value = ''.join(this_value.split())   
            # remove parens
            this_value = this_value.strip('()')
            # split by comma
            data_dict[this_param] = this_value.split(",")
            continue
        # comma delimited lists of ints with or without paren's
        if (this_param in prms['listint']):
            # remove white space
            this_value = ''.join(this_value.split())   
            # remove parens
            this_value = this_value.strip('()')
            # split by comma, map to int, store in dictionary
            data_dict[this_param] = map(int,this_value.split(","))
            continue
        # comma delimited lists of floats with or without paren's
        if (this_param in prms['listfloat']):
            # remove white space
            this_value = ''.join(this_value.split())   
            # remove parens
            this_value = this_value.strip('()')
            # split by comma, map to float, store in dictionary
            data_dict[this_param] = map(float,this_value.split(","))
            continue
        # int parameters
        if (this_param in prms['int']):
            data_dict[this_param] = int(this_value)
            continue                
        # float parameters
        if (this_param in prms['float']):
            data_dict[this_param] = float(this_value)
            continue                
        # parameters that must be handled by a user-defined function
        if (this_param in list(prms['fnc'])):
            data_dict[this_param] = prms['fnc'][this_param]['read'](this_value)
            continue                
        # otherwise
        # string parameters
        data_dict[this_param] = this_value

    #: for line

    input_file.close()
    
    return data_dict
    
#: def read_config()


# ------------------------------------------------------------------------------
#  Overwrite existing file with new values of configuration parameters
# ------------------------------------------------------------------------------

def write_config(filename,param_dict):
    """ updates an existing config file """
    
    temp_filename = "temp.cfg"
    shutil.copy(filename,temp_filename)
    output_file = open(filename,"w")
    
    # retrieve special handling info for parameters, if supplied
    prms = param_dict.prms

    # break pointers
    param_dict = copy.deepcopy(param_dict)
    
    for raw_line in open(temp_filename):
        # remove line returns
        line = raw_line.strip('\r\n')
        
        # make sure it has useful data
        if not "=" in line:
            output_file.write(raw_line)
            continue
        
        # split across equals sign
        line = line.split("=")
        this_param = line[0].strip() #Only retrieve the parameter name
        
        # skip if parameter unwanted
        if not param_dict.has_key(this_param):
            output_file.write(raw_line)
            continue
        
        # start writing parameter
        new_value = param_dict[this_param] 
        output_file.write(this_param + "= ")
        
        """ handle parameter types """

        # comma delimited list of strings inside paren's
        if (this_param in prms['liststring']):
            if not isinstance(new_value,list):
                new_value = [ new_value ]                
            output_file.write("( ")
            n_lists = len(new_value)
            for i_value in range(n_lists):
                output_file.write(new_value[i_value])
                if i_value+1 < n_lists:
                    output_file.write(", ")
            output_file.write(" )") 
        # comma delimited list of ints or floats inside paren's
        elif (this_param in prms['listint'] + prms['listfloat']):
            if not isinstance(new_value,list):
                new_value = [ new_value ]                
            output_file.write("( ")
            n_lists = len(new_value)
            for i_value in range(n_lists):
                output_file.write("%s" % new_value[i_value])
                if i_value+1 < n_lists:
                    output_file.write(", ")               
            output_file.write(" )")
        # parameters that must be handled by a user-defined function
        elif (this_param in prms['fnc']):
            output_file.write('%s' % prms['fnc'][this_param]['write'](new_value))
        # default, assume string, integer or unformatted float 
        else:
            output_file.write('%s' % new_value)

        # remove from param dictionary
        del param_dict[this_param]
        
        # next line
        output_file.write("\n")        
        
    #: for each line
        
    output_file.close()
    os.remove( temp_filename )
    
#: def write_config()


# -------------------------------------------------------------------
#  Dump configuration parameters
# -------------------------------------------------------------------

def dump_config(filename,config):
    """ dumps a raw config file with all options in config and no comments """

    config_file = open(filename,'w')
    # write dummy file with all config keys, but with values set to 0
    for key in config.keys():
        # Parameter handling instructions shouldn't be treated as parameters
        if key == 'prms' or key == '_filename':
            continue
        config_file.write( '%s= 0 \n' % key )
    config_file.close()
    # now write actual file with correct values
    write_config(filename,config)    
    
#: def dump_config()
