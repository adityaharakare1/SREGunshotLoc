# MyPythonCodes/tools/__init__.py

from misc_utils    import *
from switch        import switch
from bunch         import Bunch        as bunch
from ordered_dict  import OrderedDict  as ordered_dict
from ordered_bunch import OrderedBunch as ordered_bunch
from which         import which
from input_prms    import Params
from config        import Config
from str2num       import str2int, str2float
from caller_name   import Caller_name
from detect_peaks  import detect_peaks
from dynamic_loop  import Dynamic_loop
from findiff_Taylor_uniform import Findiff_Taylor_uniform
import redirect
import pltTools
