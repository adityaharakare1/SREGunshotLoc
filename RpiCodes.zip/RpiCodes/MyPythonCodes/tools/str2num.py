#!/usr/bin/env python

## \file str2num.py
#  \brief functions for safely converting strings to numbers
#  \author A. Sinha

def str2int(str):
    try:
        return int(str)
    except ValueError:
        raise Exception, "Expected integer but got \"" + str + "\""
        return 0

def str2float(str):
    try:
        return float(str)
    except ValueError:
        raise Exception, "Expected float but got \"" + str + "\""
        return 0.
