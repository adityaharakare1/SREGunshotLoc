from scipy.sparse import dia_matrix
from math import ceil, factorial
import numpy as np

def Findiff_Taylor_uniform(N_pts,dorder,acc):
    """
    INPUT:
    N_pts  : Number of grid points
    dorder : Order of derivative
    acc    : (Taylor) order-of-accuracy of derivative operation
    
    OUTPUT
    D   : Compressed Sparse Row format matrix for derivation operation
    
    NOTES:
    1.  The grid is uniform, with unit spacing
    2.  The field quantity whose derivative is desired is arranged as a column
        vector (1d array) with the successive entries storing the values at
        successive grid points
    3.  The derivative would be obtained by premultiplying this column vector by
        the square sparse matrix 'D' returned from here
    4.  Since the operation is a matrix multiplication, multiple column vectors
        of fields can be arranged in a 2D matrix for simultaneous computation of
        the derivative
    5.  In case of a grid with non-unit (but uniform) spacing, one should divide
        the returned 'D' matrix by (Delta**dorder), where 'Delta' is the actual
        grid spacing
    6.  Central difference is performed at internal grid points; forward and
        backward differences are performed at edge grid points where central
        difference is not applicable
    7.  Order of accuracy is necessarily even for central difference; so the
        supplied 'acc', if odd, is increased to the nearest higher even number
    """
    
    ### Preliminary type checking of inputs ###
    assert type(N_pts) is int, "N_pts is not an integer: %r" % N_pts
    assert type(dorder) is int, "dorder is not an integer: %r" % dorder
    assert type(acc) is int, "acc is not an integer: %r" % acc
    
    ### Determine the number of stencil points on either side of the pivot   ###
    ### for central difference; increase 'acc' by 1 if it's odd (see notes)  ###
    acc_c = 2*int(ceil(acc/2.)) #Accuracy in central difference
    K_c = acc_c+2*int(ceil(dorder/2.))-1 #Stencil size in central difference
    N_c = int(round((K_c-1)/2.,0)) #Side points in central difference
    
    ### Ensure that the overall grid size is large enough to support finite  ###
    ### difference of desired order and of desired order-of-accuracy         ###
    K_a = acc + dorder #Common stencil size for all forward/backward differences
    min_grid_sz = max(K_a, K_c) #Minimum allowable grid size
    assert (N_pts >= min_grid_sz), 'Grid size must be at least %d' % min_grid_sz
    
    ### Compute the stencil coefficients of the central difference operator  ###
    # Compose RHS of set of linear equations
    rhs_c = np.zeros((K_c)); rhs_c[dorder] = factorial(dorder)
    # Compose LHS operator of set of linear equations
    A_c = np.zeros((K_c,K_c))
    for idx in range(K_c):
        A_c[idx,:] = np.arange(-N_c,N_c+1)**idx
    # Solve linear set of equations to get stencil coefficients
    coeffs_c = np.linalg.solve(A_c,rhs_c)

    ### Start composing derivative operator by creating a sparse banded      ###
    ### diagonal matrix w/ central difference stencil on main diagonal band  ###
    D = dia_matrix((coeffs_c.reshape((K_c,1)).repeat(N_pts, axis=1), \
        np.arange(-N_c,N_c+1)), shape=(N_pts, N_pts))
    ### Convert sparse diagonal matrix to Compressed Sparse Row format to    ###
    ### allow subsequent matrix operations seamlessly                        ###
    D = D.tocsr()
    ### Now fill in the coefficients for the forward and backward difference ###
    ### for the first and last N_c grid points (those that cannot be covered ###
    ### by the central difference); note that these are anit-symmetric, so   ###
    ### that only one end is computed.                                       ###
    # Compose RHS of set of linear equations
    rhs = np.zeros((K_a));  rhs[dorder] = factorial(dorder)
    stencil = np.arange(0,K_a)  #mask for inserting stencils of forward diff ops
    stencil_last = N_pts-1 - stencil #corresponding mask for backward diff ops
    for kdx in range(N_c): #Go thru each edge grid point
        temp_stencil = stencil - kdx #Stencil indices for this grid point
        # Compose LHS operator of set of linear equations
        A = np.zeros((K_a,K_a))
        for idx in range(K_a):
            A[idx,:] = temp_stencil**(idx)
        # Solve linear set of equations to get stencil coefficients
        coeffs = np.linalg.solve(A,rhs)
        # Insert forward difference stencil in appropriate row of overall matrix
        D[kdx,stencil] = coeffs
        # Insert backward difference stencil also (it's anti-symmetric of above)
        D[-(kdx+1),stencil_last] = -coeffs
    
    return D

if __name__ == "__main__":

    F = Findiff_Taylor_uniform(7,2,4)
    print F.toarray()
    