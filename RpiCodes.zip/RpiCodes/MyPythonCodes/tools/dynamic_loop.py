#!/usr/bin/env python

## \file dynamic_loop.py
#  \brief dynamic nested loop
#  \author A. Sinha

import sys

# --------------------- Implements a dynamic nested loop --------------------- #
#   INPUT:
#       fnc:       function to be evaluated in inside-most loop (will take
#                  'loopIters' as argument)
#       loopRanks: list of iterations for each loop, outer-most loop first
#                  (this will reduce in size as we go deeper into the nest)
#       loopIters: current values of loop iteration counts, outer-most loop
#                  first (may be omitted on initial call)
#   OUTPUT:
#       None
# ---------------------------------------------------------------------------- #
def Dynamic_loop(fnc,loopRanks,loopIters=None):
    # No. of loops nested below (1 means we are just outside inner-most loop)
    this_nNested = len(loopRanks)
    # At initial call, either 'loopIters' is not provided, or its length must
    # be less than or equal to 'this_nNested'; in subsequent recursive calls,
    # neither of these conditions should be satisfied
    if loopIters is None or len(loopIters) <= this_nNested:
        # Indicate that none of the loops have started iterating, so that all
        # entries are 0's
        # N.B.: 'loopIters' is over-written if it was supplied at initial call
        loopIters = [0] * this_nNested
    # Total level of nesting is length of 'loopIters'
    nNestTot = len(loopIters)
    # Current level of nesting (0 means just outside outer-most loop)
    this_level = nNestTot - this_nNested
    if this_nNested > 0: #Further nested levels exist
        # Iterations at this loop level, 'this_loopRank', is indicated in the
        # first entry of 'loopRanks'
        this_loopRank = loopRanks[0]
        # list of iterations for each further nested loop (will be empty list
        # once within inner-most loop)
        further_loopRanks = loopRanks[1:]
        # actual iteration at current loop level
        for iters in range(this_loopRank):
            # update loop iteration count for this level
            loopIters[this_level] = iters
            # recursive call
            Dynamic_loop(fnc,further_loopRanks,loopIters)
    else: #Within inner-most level (no further loops)
        # Call function 'fnc' with list of loop iteration counts
        fnc(loopIters)

if __name__ == '__main__':

    def Fnc(loopIters):
        # printing
        sys.stdout.write(''.join([str(x) for x in loopIters])+'\n')

    Dynamic_loop(Fnc,[2,3,2])
