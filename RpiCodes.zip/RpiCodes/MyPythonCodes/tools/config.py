#!/usr/bin/env python

## \file config.py
#  \brief read & interpret generic configuration file and write same to file
#  \author A. Sinha (starting from SU2v4.0.0/SU2_PY/SU2/io/config.py)

#   An addition is the '_prms' attribute and the 'insert_prm' method. Together,
#   these allow a sub-class to inherit the basic functionality of this class
#   while customizing the handling of some parameters (see implementation
#   comments for details)


import os, sys, shutil, copy
from . import ordered_bunch

try:
    from collections import OrderedDict
except ImportError:
    from . import OrderedDict

# ----------------------------------------------------------------------
#  Configuration Class
# ----------------------------------------------------------------------
class Config(ordered_bunch):
    """ config = Config(filename="")
        
        Starts a config class, an extension of ordered_bunch()
        
        use 1: initialize by reading config file
            config = Config('filename')
        use 2: initialize from dictionary or bunch
            config = Config(data_dict)
        use 3: initialize empty
            config = Config()
        
        Parameters can be accessed by item or attribute
        ie: config['_filename'] or config._filename

        Attributes:
            Apart from problem-dependent attributes as specified in input file
            or initializing dict/bunch, this class has two other attributes:
            _filename - Name of the input file, if specified (default ''). Care
                        is taken to not write this out to file in 'write()'
            _prms     - Dict of special handling 'instructions' for parameters.
                        By default, all parameters are treated as strings when
                        read from a file.
                        This attribute allows 'registering' expected parameter
                        names that need different treatment (like integers,
                        floats, list of floats, user-defined functions, etc.).
                        Care is taken to not write this out to file in 'write()'
        
        Methods:
            read()  - read from a config file
            write() - write to a config file (requires existing file)
            dump()  - dump a raw config file
    """    
    def __init__(self, *args, **kwargs):
        
        # look for filename in inputs
        if args and isinstance(args[0],str):
            filename = args[0]
            args = args[1:]
        elif kwargs.has_key('filename'):
            filename = kwargs['filename']
            del kwargs['filename']
        else:
            filename = ''
        
        # initialize ordered bunch
        super(Config,self).__init__(*args,**kwargs)

        # Declare dictionary of empty lists for various parameters requiring
        # extra handling
        self._prms = {} #Empty dict
        # int parameters
        self._prms['int'] = []
        # float parameters
        self._prms['float'] = []
        # comma delimited lists of int
        self._prms['listint'] = []
        # comma delimited lists of floats
        self._prms['listfloat'] = []
        # comma delimited lists of strings with or without parentheses
        self._prms['liststring'] = [] 
        # external functions
        self._prms['fnc'] = {} #Empty dictionary, NOT list
        
        # read config if it exists
        if filename:
            try:
                self.read(filename)
            except IOError:
                print 'Could not find config file: %s' % filename
	    except:
		print 'Unexpected error: ',sys.exc_info()[0]
		raise
        
        self._filename = filename
    
    """ insert (register) name of parameter requiring extra handling (should be
        called before parameter file is read)
    
        Inputs:
            keyword - name of parameter (expected in input file)
            vartype - type of parameter (integer, float, list of float,
                      user-defined, etc.) (default is string, for which this
                      method should not be called)
            fnc_rd  - in case of user-defined parameter type, function to read
                      and interpret the parameter
            fnc_wrt - in case of user-defined parameter type, function to write
                      out parameter value to file (inverse of 'fnc_rd')
    """
    def insert_prm(self,keyword,vartype,fnc_rd=None,fnc_wrt=None):
        if vartype.lower() == 'int':
            self._prms['int'].append(keyword) #Append to running integers' list
        elif vartype.lower() == 'float':
            self._prms['float'].append(keyword) #floats' list
        elif vartype.lower() == 'listint':
            self._prms['listint'].append(keyword) #list of integers' list
        elif vartype.lower() == 'listfloat':
            self._prms['listfloat'].append(keyword) #list of floats' list
        elif vartype.lower() == 'liststring':
            self._prms['liststring'].append(keyword) #list of strings' list
        elif vartype.lower() == 'fnc':
            self._prms['fnc'][keyword] = {} #user-defined types' list
            self._prms['fnc'][keyword]['read'] = fnc_rd   #register reader
            self._prms['fnc'][keyword]['write'] = fnc_wrt #register writer
    
    """ reads from a config file """
    def read(self,filename):
        _prms = self._prms if hasattr(self,'_prms') else {}
        konfig = read_config(filename,_prms)
        self.update(konfig)

    """ updates an existing config file """
    def write(self,filename=''):
        if not filename: filename = self._filename
        assert os.path.exists(filename), 'must write over existing config file'
        write_config(filename,self)
        
    """ dumps all items in the config bunch, without comments """
    def dump(self,filename=''):
        if not filename: filename = self._filename
        dump_config(filename,self)

    """ slightly more verbose handling of AttributeError """
    def __getattr__(self,k):
        try:
            return super(Config,self).__getattr__(k)
        except AttributeError:
            raise AttributeError, self.__class__.__name__+' parameter not found'
        
    """ slightly more verbose handling of KeyError """
    def __getitem__(self,k):
        try:
            return super(Config,self).__getitem__(k)
        except KeyError:
            raise KeyError, self.__class__.__name__+' parameter not found: %s'%k

    """ informal string representation of class, sans '_prms' attribute """
    def __str__(self):
        output = '%s: %s' % (self.__class__.__name__,self._filename)
        for k,v in self.iteritems():
            if k == '_prms' or k == '_filename': continue #Skip _prms & filename
            output +=  '\n    %s= %s' % (k,v)
        return output

#: endclass Config


# ------------------------------------------------------------------------------
#  Read configuration parameters line-by-line from file and interpret according
#  to their respective specified types in '_prms' (default is string)
# ------------------------------------------------------------------------------
def read_config(filename,_prms):
    data_dict = OrderedDict() # initialize output dictionary
    for line in open(filename): # process till EOF
        if not line: break #EOF
        line = line.strip('\r\n') # remove line returns
        if (not "=" in line) or (line[0] == '%'): continue # ensure useful data
        line = line.split("=",1) # split across equals sign
        this_param = line[0].strip() # parameter keyword is LHS of '='
        this_value = line[1].strip() # parameter value is RHS of '='
        assert not data_dict.has_key(this_param) , \
            ('Config file has multiple specifications of %s' % this_param )
        # handle parameter types
        if (this_param in _prms['int']):
            # int parameters
            data_dict[this_param] = int(this_value)
        elif (this_param in _prms['float']):
            # float parameters
            data_dict[this_param] = float(this_value)
        elif (this_param in _prms['listint']):
            # comma delimited lists of ints with or without paren's
            this_value = ''.join(this_value.split()) # remove white space
            this_value = this_value.strip('()') # remove parens
            # split by comma, map to int, store in dictionary
            data_dict[this_param] = map(int,this_value.split(","))
        elif (this_param in _prms['listfloat']):
            # comma delimited lists of floats with or without paren's
            this_value = ''.join(this_value.split()) # remove white space
            this_value = this_value.strip('()') # remove parens
            # split by comma, map to float, store in dictionary
            data_dict[this_param] = map(float,this_value.split(","))
        elif (this_param in _prms['liststring']):
            # comma delimited lists of strings with or without paren's
            this_value = ''.join(this_value.split()) # remove white space
            this_value = this_value.strip('()') # remove parens
            data_dict[this_param] = this_value.split(",") # split by comma
        elif (this_param in list(_prms['fnc'])):
            # parameter to be handled by user-defined read function
            data_dict[this_param] = _prms['fnc'][this_param]['read'](this_value)
        else:
            # string parameter
            data_dict[this_param] = this_value
    #: endfor line in open(filename)
    return data_dict # return ordered data dictionary
#: enddef read_config()


# ------------------------------------------------------------------------------
#  Update/overwrite existing file with new values of configuration parameters;
#  use parameter types specified in '_prms' to produce appropriate output
# ------------------------------------------------------------------------------
def write_config(filename,data_dict):
    temp_filename = "temp.cfgtmp"
    shutil.copy(filename,temp_filename) # copy for reading (will delete at end)
    # retrieve special handling info for parameters, if supplied
    _prms = data_dict._prms if hasattr(data_dict,'_prms') else {}
    data_dict = copy.deepcopy(data_dict) # break pointers (manipulated here)
    output_file = open(filename,"w") # open file for writing
    for raw_line in open(temp_filename): # process till EOF
        line = raw_line.strip('\r\n') # remove line returns
        if (not "=" in line) or (line[0] == '%'): # dump directly if no data
            output_file.write(raw_line)
            continue 
        line = line.split("=",1) # split across equals sign
        this_param = line[0].strip() # parameter keyword is LHS of '='
        # dump directly if this parameter is unspecified in 'data_dict'
        if not data_dict.has_key(this_param):
            output_file.write(raw_line)
            continue
        new_value = data_dict[this_param] # new value of this parameter
        output_file.write(this_param + "= ") # start writing to file
        if (this_param in _prms['listint']+_prms['listfloat']+_prms['liststring']):
            # comma delimited list of ints, floats or strings inside paren's
            if not isinstance(new_value,list):
                new_value = [ new_value ]                
            output_file.write("( ")
            n_lists = len(new_value)
            for i_value in range(n_lists):
                output_file.write("%s" % new_value[i_value])
                if i_value+1 < n_lists:
                    output_file.write(", ")               
            output_file.write(" )")
        elif (this_param in _prms['fnc']):
            # parameters that must be handled by a user-defined function
            output_file.write('%s'%_prms['fnc'][this_param]['write'](new_value))
        else:
            # default: string, integer or float 
            output_file.write('%s' % new_value)
        del data_dict[this_param] # remove current parameter from dictionary
        output_file.write("\n") # write out newline character in prep for next
    #: endfor raw_line
    output_file.close() # close text file
    os.remove( temp_filename ) # delete temporary file (copied for reading)
#: enddef write_config()


# ------------------------------------------------------------------------------
#  Dump a raw config file with all parameters but no comments
# ------------------------------------------------------------------------------
def dump_config(filename,config):
    # first write dummy file with all config keys, but with values set to 0
    config_file = open(filename,'w')
    for key in config.keys():
        # Parameter handling instructions shouldn't be treated as parameters
        if key == '_prms' or key == '_filename':
            continue
        config_file.write( '%s= 0 \n' % key )
    config_file.close()
    # now write actual file with correct values
    write_config(filename,config)
#: enddef dump_config()
