#!/usr/bin/env python

## \file misc_utils.py
#  \brief miscellaneous utilities

import os, shutil, glob

def is_non_zero_file(fpath):
    """ determine if supplied filepath is a file and if it is not empty """
    return os.path.isfile(fpath) and os.path.getsize(fpath) > 0


def make_link(src,dst):
    """ make_link(src,dst)
        makes a relative link
        Inputs:
            src - source file
            dst - destination to place link
        
        Windows links currently unsupported, will copy file instead
        
        Copied from SU2v4.0.0/SU2_PY/SU2/io/tools.py
    """
    
    assert os.path.exists(src) , 'source file does not exist \n%s' % src
    
    if os.name == 'nt':
        # can't make a link in windows, need to look for other options
        if os.path.exists(dst): os.remove(dst)
        shutil.copy(src,dst)
    
    else:
        # find real file, incase source itself is a link
        src = os.path.realpath(src) 
        
        # normalize paths
        src = os.path.normpath(src)
        dst = os.path.normpath(dst)        
        
        # check for self referencing
        if src == dst: return        
        
        # find relative folder path
        srcfolder = os.path.join( os.path.split(src)[0] ) + '/'
        dstfolder = os.path.join( os.path.split(dst)[0] ) + '/'
        srcfolder = os.path.relpath(srcfolder,dstfolder)
        src = os.path.join( srcfolder, os.path.split(src)[1] )
        
        # make unix link
        if os.path.exists(dst): os.remove(dst)
        os.symlink(src,dst)

def nextFile(namePre,namePost="",isdir=False,parent='.'):
    """ compose name of next-available file (or folder), whose format is
            namePre+str(non-negative integer)+namePost
        
        INPUTS:
        namePre:  prefix of file/folder name
        namePost: postfix of file/folder name
        isdir:    Folder (True) or file (False) or anything (None)
        parent:   parent path in which to look for file/folder matching pattern
        
        OUTPUTS:
        filename: name of next-available file/folder
    """
    lastNo = -1 #initialize last file number to impossibly-low number
    # retrieve all paths in matching pattern
    for matchPath in glob.glob(os.path.join(parent,namePre+'*'+namePost)):
        if isdir is not None: #both file and folder are allowed
            if isdir and not os.path.isdir(matchPath): #only folder allowed
                continue
            if not isdir and not os.path.isfile(matchPath): #only file allowed
                continue
        match = os.path.basename(matchPath) #remove path to parent folder
        # get this file's number
        try:
            currNo = int(match.replace(namePre,"").replace(namePost,""))
        except: #omit this match if exception occurs in string-to-int conversion
            continue
        if currNo > lastNo: 
            lastNo = currNo #update highest (last) file number
    return namePre+str(lastNo+1)+namePost #compose name and return
