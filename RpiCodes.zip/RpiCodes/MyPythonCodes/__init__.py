# MyPythonCodes/__init__.py

import tools

