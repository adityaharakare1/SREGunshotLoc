#!/usr/bin/python 

#  \brief class for simulating gunshot signatures
#  \author A. Sinha

import os, math, copy
import numpy as np
from matplotlib import pyplot as plt

from MyPythonCodes.tools import redirect

import tools
from . import Config_GunshotSim

filenameFirearmDtls = 'firearms_details.txt'
filenameBulletDtls = 'bullets_details.txt'
atmPressure = 101325 #Pa

class GunshotSgntrSimProject(object):
    
    def __init__(self,configIn,projPath='.'):
        # refer back to supplied configuration object, or retrieve same from
        # filename, whichever is supplied in 'configIn'
        self.config = Config_GunshotSim(configIn)
        self.projPath = projPath
        rdr = tools.dataAccess.DataAccess(self.projPath)
        rdr.readLog()
        self.log = rdr.log

    def simProject(self,options=None):
        with redirect.folder(self.projPath):
            link = [filenameFirearmDtls, tools.environment.filenameSensLoc]
            for fldr, srcLoc in zip(self.log['fldrs'],self.log['srcCoords']):
                with redirect.folder(os.path.join(fldr,'Event0'),link=link,force=True):
                    configOut = copy.deepcopy(self.config)
                    configOut.srcLoc = list(srcLoc)
                    configOut.dump(tools.dataAccess.configFname)
                    gsss = GunshotSgntrSim(configOut)
                    gsss.sim(options)

class GunshotSgntrSim(object):
    """ class for simulating gunshot signatures
    
        ATTRIBUTES:
        config:  configuration object
        env:     'Environment' object
        srcLoc:  ndarray of source coordinates
        dt0Fctr: fraction of sampling period by which first time sample should
                 be advanced w.r.t. arrival time of sound at nearest sensor
        mzlPrms: dict object of gunshot parameters
        
        METHODS:
        sim:           simulate gunshot signatures at all sensors
        _simBlastSnsr: simulate muzzle blast signature recorded at a sensor
    """
    def __init__(self,configIn,dataFldr='.'):
        """ initialization
        
            INPUTS:
            configIn: configuration object, or filename of same
            dataFldr: path to data folder (default: pwd)
        """
        # refer back to supplied configuration object, or retrieve same from
        # filename, whichever is supplied in 'configIn'
        config = Config_GunshotSim(configIn)
        
        # register relevant parameters from config in self        
        self.config = config
        self.srcLoc = np.array(self.config.srcLoc)
        self.dt0Fctr = 0. if not hasattr(config,'dt0Fctr') else config.dt0Fctr

        # create the 'Environment' object for the problem
        self.env = tools.Environment(config,dataFldr)

        if hasattr(config,'firearmNo'):
            # retrieve firearms details from data sheet
            firearmSht = np.loadtxt(os.path.join(dataFldr,filenameFirearmDtls),\
                comments="#")
            # get array of parameters for firearm number specified in config
            mzlPrms = firearmSht[config.firearmNo]
            
            # create a dict object with gunshot parameters
            self.mzlPrms = {
                'bulletSpd': mzlPrms[1], #bullet speed
                'blstRise':  mzlPrms[2], #blast wave rise time [s]
                'blstPeak':  mzlPrms[3], #blast wave peak value [Pa]
                'blstDcay':  mzlPrms[4], #blast wave 0-cross time after peak [s]
                'blstTotT':  mzlPrms[5], #blast wave total duration [s]
            }
        else:
            self.mzlPrms = None

        if hasattr(config,'bulletNo') and hasattr(config,'bulletDir'):
            # retrieve bullet details from data sheet
            bulletSht = np.loadtxt(os.path.join(dataFldr,filenameBulletDtls), \
                comments="#")
            # get array of parameters for bullet number specified in config
            bltPrms = bulletSht[config.bulletNo]
            # create a dict object with gunshot parameters
            self.bltPrms = {
                'Spd': bltPrms[1], #bullet speed [m/s]
                'Dia': bltPrms[2], #bullet diameter [mm]
                'Len': bltPrms[3], #bullet length [mm]
                'Wt':  bltPrms[4], #bullet weight [g]
                'Mach': bltPrms[1]/self.config.sndSpd, #bullet Mach number
            }
            # shock cone (Mach) angle (in case of supersonic bullet)
            if self.bltPrms['Mach'] > 1:
                self.bltPrms['MachAngle'] = math.asin(1/self.bltPrms['Mach'])
            else:
                self.bltPrms['MachAngle'] = np.nan
            # store bullet direction from config object in self    
            self.bulletDir = config.bulletDir
        else:
            self.bltPrms = None
            self.bulletDir = None
        
        # create global time axis that is the minimal applicable for all sensors
        self.t = self.createTimeAxis()

    def createTimeAxis(self):
        """ create global time axis that is the minimal applicable for all
            sensors
        """
        sndSpd = self.config.sndSpd
        dt = self.config.dt
        ## create an array of distances from source to all sensors
        dists = np.empty((0),dtype=np.float) #declare as empty
        for Clstr in self.env.Clusters: #go thru all clusters
            for Snsr in Clstr.Sensors: #go thru all sensors in this cluster
                # calculate Euclidean distance of this sensor from source
                distCurr = [np.linalg.norm(self.srcLoc-Snsr.coords)]
                # append to expanding array of sensor distances
                dists = np.append(dists,distCurr)
        # determine the initial instant of the global time axis (need not start
        # from gunshot instant t = 0, as that may be wasteful); this is given by
        # the acoustic propagation time to the nearest sensor (min of 'dists');
        # use 'dt0Fctr' and 'dt' to start from slightly earlier
        if self.bltPrms:
            maxSpd = max(sndSpd,self.bltPrms['Spd'])
        else:
            maxSpd = sndSpd
        tIni = np.amin(dists)/maxSpd - self.dt0Fctr*dt
        # determine the final instant of the global time axis; this is given by
        # the acoustic propagation time to the farthest sensor (max of 'dists')
        # plus twice the typical length of time beyond an event for which data
        # is needed
        tFin = np.amax(dists)/sndSpd + self.config.tAft*2.
        # number of time samples from above initial and final times and sampling
        # period 'dt'
        nT = int(math.ceil((tFin - tIni)/dt)) + 1
        # the global time array that is applicable to all sensors, based on
        # above parameters
        return np.array(range(nT))*dt + tIni

    def sim(self,options=None):
        """ simulate gunshot signatures recorded at all sensors
        """
        plot = (options is not None and 'plot' in options and options['plot'])
        if plot:
            plt.figure()
        for Clstr in self.env.Clusters:
            for Snsr, iSnsr in zip(Clstr.Sensors,range(Clstr.nSensors)):
                evntWrt = True if iSnsr == 0 else False
                BlastDat = self._simBlastSnsr(Snsr,evntWrt)
                ShockDat = self._simShockSnsr(Snsr,evntWrt)
                SgntrDat = BlastDat + ShockDat
                with open(Snsr.fnDataFl,'wb') as fileObj:
                    SgntrDat.astype(Snsr.dtype).tofile(fileObj)
                if plot:
                    plt.plot(self.t,SgntrDat)
        if plot:
            plt.show()

    def _simBlastSnsr(self,Snsr,evntWrt):
        """ simulate muzzle blast signature recorded at a sensor
        
            INPUT:
            Snsr:    sensor object
            evntWrt: whether to write event sample index to file, or not
            
            OUTPUT:
            BlastDat: array like 't', populated with simulated blast wave
        """
        if not self.mzlPrms:
            return np.zeros_like(self.t)            
        # calculate Euclidean distance of this sensor from source
        distCurr = np.linalg.norm(self.srcLoc-Snsr.coords)
        # calculate arrive time based on above distance and speed of sound,
        # assuming that gunshot (blast) occured at t = 0
        t_arrv = distCurr/self.config.sndSpd
        # make a copy of gun parameters
        mzlPrms = copy.deepcopy(self.mzlPrms)
        # modify blast peak to account for decay of muzzle blast inversely
        # with distance from source, assuming that the original value specified
        # is at unit distance from the gun
        mzlPrms['blstPeak'] = mzlPrms['blstPeak']/distCurr
        # use the Friedlander function to model the muzzle blast wave, and
        # cast the resulting data array to the appropriate data type
        BlastDat = np.array(Friedlander(self.t,t_arrv,mzlPrms),dtype=Snsr.dtype)
        if evntWrt: #if the event sample index is to be written to file
            iPk = np.argmax(BlastDat) #index of peak
            with open(Snsr.fnEvntFl,'w') as fileObj: #open file for writing
                fileObj.write(str(iPk)) #write sample index of peak
        return BlastDat
    #enddef _simBlastSnsr

    def _simShockSnsr(self,Snsr,evntWrt):
        """ simulate bullet shock wave signature recorded at a sensor
        
            INPUT:
            Snsr:    sensor object
            evntWrt: whether to write event sample index to file, or not
            
            OUTPUT:
            ShockDat: array like 't', populated with simulated shock wave
        """
        if not self.bltPrms or self.bltPrms['Mach'] < 1. or not self.bulletDir:
            return np.zeros_like(self.t)
        # time of arrival of bullet at closest-point-of-approach (CPA) for
        # sensor, after being released from gun at t = 0
        t_blt_CPA = np.dot((Snsr.coords - self.srcLoc),self.bulletDir) \
            /np.linalg.norm(self.bulletDir)/self.bltPrms['Spd']
        # miss distance of trajectory w.r.t. sensor [eqn. 17 of Makinen2010]
        missDist = np.linalg.norm(np.cross((Snsr.coords - self.srcLoc), \
            self.bulletDir))/np.linalg.norm(self.bulletDir)
        # time of arrival of bullet at launch point of shock wave that reaches
        # the sensor
        t_blt_lnch = t_blt_CPA - missDist*math.tan(self.bltPrms['MachAngle']) \
            /self.bltPrms['Spd']
        if t_blt_lnch < 0:
            # if the sensor location is such that the bullet needs to have been
            # launched at negative time, then this sensor will not get the shock
            return np.zeros_like(self.t)
        # shock wave amplitude [Whitham model]
        Amp = 0.53*atmPressure*(self.bltPrms['Mach']**2-1)**0.125 \
            *(self.bltPrms['Dia']*1.e-3)/missDist**0.75 \
            /(self.bltPrms['Len']*1e-3)**0.25
        # shock wave duration [Whitham model]
        Duration = 1.82*self.bltPrms['Mach']*missDist**0.25 \
            *(self.bltPrms['Dia']*1.e-3)/self.config.sndSpd \
            /(self.bltPrms['Mach']**2-1)**0.375/(self.bltPrms['Len']*1e-3)**0.25
        # calculate arrive time based on launch time and time required by sound
        # to traverse the intervening distance
        t_arrv = t_blt_lnch + missDist/math.cos(self.bltPrms['MachAngle']) \
            /self.config.sndSpd
        # use the N-wave to model the shock wave, and cast the resulting data
        #array to the appropriate data type
        ShockDat = np.array(NWave(self.t,t_arrv,Amp,Duration),dtype=Snsr.dtype)
        if evntWrt: #if the event sample index is to be written to file
            iPk = np.argmax(ShockDat) #index of peak
            with open(Snsr.fnEvntFl,'w') as fileObj: #open file for writing
                fileObj.write(str(iPk)) #write sample index of peak
        return ShockDat
    #enddef _simShockSnsr

# endclass GunshotSgntrSim

def Friedlander(t,t_arrv,blstPrms):
    """ Friedlander profile for modelling muzzle blast wave pressure signal
    
        INPUTS:
        t:        time array at which blast wave pressure is desired [s]
        t_arrv:   arrival time of blast wave at sensor (Friedlander wave start)
        blstPrms: dict object of blast wave parameters
        
        OUTPUT:
        data: array like 't', populated with simulated pressure signal
    """
    data = np.zeros_like(t) #allocate return array and initialize with 0's
    blstRise = blstPrms['blstRise'] #blast wave rise time [s]
    blstPeak = blstPrms['blstPeak'] #blast wave peak value [Pa]
    blstDcay = blstPrms['blstDcay'] #blast wave time to go -ve after peak [s]
    t_peak = t_arrv + blstRise #time of peak at sensor
    # determine index in 't' where it is just greater than 't_arrv'
    iTIni = np.where(t > t_arrv)[0][0]
    # determine index in 't' where it is just greater than 't_peak'
    iTPk = np.where(t > t_peak)[0][0]
    # simulate rising part of wave at appropriate time instants (uniform rise)
    data[iTIni:iTPk] = blstPeak*(t[iTIni:iTPk] - t_arrv)/blstRise
    # remaining time array (after peak), scaled by decay time
    x = (t[iTPk:]-t_peak)/blstDcay
    # simulate decaying part of wave at appropriate time instants
    data[iTPk:] = blstPeak*(1-x)*np.exp(-x)
    return data
#enddef Friedlander

def NWave(t,t_arrv,amp,duration):
    """ N-wave profile for modelling shock wave pressure signal
    
        INPUTS:
        t:        time array at which shock wave pressure is desired [s]
        t_arrv:   arrival time of shock wave at sensor (N-wave start) [s]
        amp:      amplitude of N-wave (+ve and -ve peaks) [Pa]
        duration: duration of N-wave [m]
        
        OUTPUT:
        data: array like 't', populated with simulated pressure signal
    """
    data = np.zeros_like(t) #allocate return array and initialize with 0's
    t_end = t_arrv + duration #time of N-wave end at sensor
    # determine index in 't' where it is just greater than 't_arrv'
    iTIni = np.where(t > t_arrv)[0][0]
    # determine index in 't' where it is just lesser than 't_end'
    iTend = np.where(t <= t_end)[0][-1]
    # simulate rising part of wave at appropriate time instants (uniform rise)
    data[iTIni:iTend] = amp*(1. - 2.*(t[iTIni:iTend] - t_arrv)/duration)
    return data
#enddef NWave
