#!/usr/bin/env python

#  \brief interpret config file for gunshot simulation
#  \author A. Sinha

import sys
from tools import Config_Gunshot

class Config_GunshotSim(Config_Gunshot):
    """ Starts a config class inherited from Config_Gunshot, with added specific
        handling info for some parameters
        
        for usage, attributes and methods, see super class
    """    
    
    def __init__(self,*args,**kwarg):
        
        # look for filename in inputs, retrieve it, and remove from args/kwarg
        if args and isinstance(args[0],str):
            filename = args[0]
            args = args[1:]
        elif kwarg.has_key('filename'):
            filename = kwarg['filename']
            del kwarg['filename']
        else:
            filename = ''
        
        # initialize Config (either empty or with config object)
        super(Config_GunshotSim,self).__init__(*args,**kwarg)

        # insert parameters that require special handling
        self.insert_prm('firearmNo','int') #firearm index into table
        self.insert_prm('srcLoc','listfloat') #source location coordinates
        self.insert_prm('dt0Fctr','float') #fraction of sampling period by which
                                           #first time sample should be advanced
                                           #w.r.t. arrival time of event at
                                           #nearest sensor
        self.insert_prm('bulletNo','int') #bullet index into table
        self.insert_prm('bulletDir','listfloat') #bullet trajectory vector
        

        # read config if it exists
        if filename:
            try:
                self.read(filename)
            except IOError:
                print 'Could not find config file: %s' % filename
            except:
                print 'Unexpected error: ',sys.exc_info()[0]
                raise
        
        self._filename = filename

#: endclass Config_GunshotSim
