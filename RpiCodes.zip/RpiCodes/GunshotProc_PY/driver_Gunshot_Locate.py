#!/usr/bin/python

from optparse import OptionParser
import numpy as np
import tools, locate, detect
import time
import struct as st
import socket
from os.path import join
import math

_ipAddr = '169.254.70.92'
_cnnctPort = 5002


_debugFile = 'gunshotLoc_debug.txt'

def main():


    parser=OptionParser()
    parser.add_option("-c", dest="nchnl", default="4")      #No. of channels
    parser.add_option("-b", dest="buffer", default="1400")  #Data buffer size
    parser.add_option("-f", dest="filename")                #Config filename
    parser.add_option("-p", dest="path", default=".")       #Working path
    parser.add_option("-d", dest="debug", default="0")      #Debug level flag
    parser.add_option("-o", dest="dbgfl", default=_debugFile) #Debug filename 
    (options, args) = parser.parse_args()

    TOT_CHN = int(options.nchnl)
    BUFFER_SIZE = int(options.buffer)
    FLAG_DEBUG = int(options.debug)
    DEBUG_FILE = options.dbgfl
    WRK_PATH = options.path

    data = np.zeros((TOT_CHN,BUFFER_SIZE/2))

    sckt = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sckt.bind((_ipAddr,_cnnctPort))
    sckt.listen(1)
    conn, addr = sckt.accept()

    eventCount = 0  #Initialize to 0
    while(1):
        count = conn.recv(1) #event number
        bi_event = conn.recv(4) #number of interrupts from start
        i_evnt = conn.recv(2) #index of triggered channel
        i_first = conn.recv(1) #triggered channel number

        flagRecv = True
        for iChnl in range(TOT_CHN):
            chnl = conn.recv(1)
            try:
                a = str(chnl)
            except TypeError:
                flagRecv = False
                break
            dataCurr = conn.recv(BUFFER_SIZE)
            jChnl = int(str(chnl)) - 1 #Received is 1-based channel index
            try:
                data[jChnl] = st.unpack((BUFFER_SIZE/2)*"H",dataCurr)
            except st.error:
                flagRecv = False
                break

        # Found another event
        eventCount += 1

        if FLAG_DEBUG >= 10:
            # Write the current event count to debug file
            with open(join(WRK_PATH,DEBUG_FILE),'a') as did:
                did.write('\nEvent count = '+str(eventCount)+'\n')
            # Append channels' data (as uint16) to binary files, channel-wise
            for iChnl in range(TOT_CHN):
                with open(join(WRK_PATH,"tiva_data_"+str(iChnl)+".bin"),"ab") as fid:
                    data[iChnl].astype(np.uint16).tofile(fid)
        
        if FLAG_DEBUG >= 50:
            # For high enough debug level, store samples of channels' data
            index0 = min(30,BUFFER_SIZE-1)
            indexn = min(50,BUFFER_SIZE)
            with open(join(WRK_PATH,DEBUG_FILE),'a') as did:
                for iChnl in range(TOT_CHN):
                    did.write('data['+str(iChnl)+']['+str(index0)+':'+str(indexn)+'] = ' \
                        +np.array_str(data[iChnl][index0:indexn].astype(np.uint16))+'\n')

        # Ground reflection removal
        for iChnl in range(TOT_CHN):
            grnd = detect.EventReflection(data[iChnl]) #Instantiate class w/ data
            grnd.detect(options={'plot':False})        #Detect ground reflection
            grnd.correct(options={'plot':False})       #Correct for same
            data[iChnl] = grnd.y        #Overwrite channel data w/ corrected data
            if FLAG_DEBUG >= 100:
                # For high enough debug level, store the corrected data to files
                with open(join(WRK_PATH,"grnd_crctd_"+str(iChnl)+".bin"),"ab") as gid:
                    data[iChnl].tofile(gid)

        # Event categorization
        categorize = detect.EventCategorize(data,options.filename)
        evnt_cat = categorize.categorize()

        if evnt_cat != 1:
            #if event is muzzle_blast
            env = tools.Environment(data,options.filename,dataFldr=options.path)
            env.rtrvData()

            slvrOptions = {'plot': False,
                   'debug': False,
                   'autoReorder': True,
                   'TDOA': True}
            
            # Use wavefront-curvature method to calculate the best guess for the
            # source location, using all possible combinations of sensor-triplets
            # in separate clusters
            slvr0 = locate.WaveFrontCurveMethod(env)
            slvr0.calcBestSrcLocClstr(slvrOptions)
            # In some bad cases, no solution may come out of the above calculations.
            # In such cases, we set the guess for the source location to the
            # centroid of the sensor array (for lack of anything else to do).
            if slvr0.srcLocs is not None:
                srcLoc0 = slvr0.srcLocs
            else:
                srcLoc0 = env.Clusters[0].centroid

            # Instantiate nonlinear least-squares method class for localization
            slvr = locate.NLLSEMethod(env)
            # Determine the best candidate for the reference sensor
            slvr.calcBestRefSnsr(slvrOptions)
            # Use the 'snsr_ref1' attribute populated in the above method call to
            # retrieve the reference sensor object's coordinates
            snsr_ref1_coords = env.Clusters[0].Sensors[slvr.snsr_ref1].coords
            # Estimate the event origin time given that it reaches the reference
            # sensor at about t = 0 
            tEvnt0 = - np.linalg.norm(srcLoc0 - snsr_ref1_coords[:len(srcLoc0)])/env.config.sndSpd
            # Use the above estimates to initialize the nonlinear least-squares solution
            slvr.calcSrcLoc(srcLoc0,tEvnt0,slvr.snsr_ref1,plot=False,debug=False)

            solRTh = np.zeros((2))
            solRTh[0] = np.linalg.norm(slvr.srcLocs)
            solRTh[1] = math.atan2(slvr.srcLocs[1],slvr.srcLocs[0])*180./math.pi

            # Write the source location found above to file
            with open(join(WRK_PATH,"src_loc.txt"),"a") as oid:
                oid.write(str(eventCount)+': '+str(slvr.srcLocs)+'; '+str(solRTh)+'\n')

            if FLAG_DEBUG:
                dbg_str = 'NLSE: srcLoc0 = '+np.array_str(srcLoc0[:2]) \
                        +', srcLocXY = '+np.array_str(slvr.srcLocs) \
                        +', srcLocRTh = '+np.array_str(solRTh)
                if FLAG_DEBUG >= 10:
                    with open(join(WRK_PATH,DEBUG_FILE),'a') as did:
                        did.write(dbg_str+'\n')
                print 'Event count = '+str(eventCount)+': '+dbg_str

    conn.close()

if __name__ == '__main__':
    main()

