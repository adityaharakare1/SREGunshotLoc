import os

os.system("./driver_Gunshot_Locate.py")
