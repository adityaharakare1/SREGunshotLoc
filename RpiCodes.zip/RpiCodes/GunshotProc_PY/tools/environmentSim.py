#!/usr/bin/python 

#  \brief classes for managing environment, cluster and sensor in simulation
#  \author A. Sinha

import os, math
import numpy as np
from matplotlib import pyplot as plt

from MyPythonCodes.tools import pltTools

from . import Config_Gunshot

# File where sensor location info is presented
filenameSensLoc = 'sensor_locations.txt'

class SensorSim(object):
    """ class for managing sensor data in a simulation where the source location
        is known a priori
        
        ATTRIBUTES:
        sensorNo: sensor index
        coords:   coordinate (array) of sensor
            
        METHODS:
        None
    """  

    def __init__(self,sensorNo,coords):
        """ initialization
        
            INPUTS:
            sensorNo: this sensor's index
            coords:   coordinate (array) of sensor
        """
        ## store the input arguments
        self.sensorNo = sensorNo
        # trivial coordinates (like z-coordinate in 2D) may be omitted in input
        self.coords = np.zeros((3),dtype=np.float)
        self.coords[:coords.shape[0]] = np.array(coords)

# endclass SensorSim

class ClusterSim(object):
    """ class for managing a cluster of sensors deployed in a problem and their
        mutual relationship (in terms of propagation delays of an event of
        interest) in a simulation where the source location is known a priori

        ATTRIBUTES:
        srcLoc:    coordinates of source
        clusterNo: cluster index
        iSensors:  list of sensor indices in cluster
        nSensors:  number of sensors in cluster
        Sensors:   sensor objects' list corresponding to sensors in cluster
        IDelays:   square matrix of mutual sample delays between each pair of
                   sensors in cluster
        Dists:     square matrix of mutual distances between each pair of
                   sensors in cluster
        dt:        sampling period of sensors
        sndSpd:    speed of sound
        centroid:  centroid of the cluster

        METHODS:
        interSnsrDist:  Euclidean distance between two sensors in cluster
        interSnsrAngHz: angle of vector from reference sensor to working sensor
                        w.r.t. x-axis in horizontal plane (ignores z-coordinate)
        calcIDelayPair: calculate entry in 'IDelays' for a given sensor pair
        calcIDelaysAll: populate 'IDelays'
        calcCentroid:   calculate centroid of cluster
        plot:           plot geometry of cluster
    """
    
    def __init__(self,srcLoc,configIn,clusterNo,dataFldr='.'):
        """ initialization
        
            INPUTS:
            srcLoc:    coordinates of source
            configIn:  configuration object, or filename of same
            clusterNo: this cluster's index
            dataFldr:  path to data folder (default: pwd)
        """
        # refer back to supplied configuration object, or retrieve same from
        # filename, whichever is supplied in 'configIn'
        self.srcLoc = srcLoc
        config = Config_Gunshot(configIn)
        self.clusterNo = clusterNo
        self.iSensors = config.snsrClstrs[clusterNo]
        self.nSensors = len(self.iSensors)
        self.Sensors = []
        self.IDelays = np.zeros((self.nSensors,self.nSensors),dtype=np.int64)
        self.dt = config.dt
        self.sndSpd = config.sndSpd

        # read coordinates of all sensors in environment from tabulated file
        # whose row index corresponds to sensor index
        coords = np.loadtxt(os.path.join(dataFldr,filenameSensLoc), \
            comments="#")
        # register all sensors in the cluster: populate 'Sensors' list with
        # objects of 'Sensor' class, using their coordinates retrieved above
        for iSns in range(self.nSensors): #for all sensors in environment
            # append this sensor to list
            self.Sensors.append(SensorSim(self.iSensors[iSns], \
                coords[self.iSensors[iSns]]))
        
        # populate the 'Dists' square matrix
        self.Dists = np.zeros((self.nSensors,self.nSensors))
        for iSnsr in range(self.nSensors): # go thru all sensors
            for jSnsr in range(iSnsr+1,self.nSensors): # go thru all remaining
                self.Dists[iSnsr,jSnsr] = self.interSnsrDist(iSnsr,jSnsr)
                # use the fact that the matrix is symmetric, with zero diagonal
                self.Dists[jSnsr,iSnsr] = self.Dists[iSnsr,jSnsr]

        # centroid of the cluster
        self.centroid = self.calcCentroid()

    def interSnsrDist(self,iSnsrRef,iSnsrWrk):
        """ Euclidean distance between reference and working sensors """
        return np.linalg.norm(self.Sensors[iSnsrWrk].coords \
            - self.Sensors[iSnsrRef].coords)

    def interSnsrAngHz(self,iSnsrRef,iSnsrWrk):
        """ angle of vector from reference sensor to working sensor w.r.t.
            x-axis in horizontal plane (ignores z-coordinate)
        """
        angle = math.atan2(\
            self.Sensors[iSnsrWrk].coords[1]-self.Sensors[iSnsrRef].coords[1],\
            self.Sensors[iSnsrWrk].coords[0]-self.Sensors[iSnsrRef].coords[0])
        if angle < 0:
            angle = angle + 2*math.pi
        return angle

    def calcIDelayPair(self,iSnsrRef,iSnsrWrk):
        """ calculates 'IDelay' as described below, by using the known source
            location
            
            INPUT:
            iSnsrRef: index of 'reference' sensor in 'Sensors' list
            iSnsrWrk: index of 'working' sensor in 'Sensors' list
            
            OUTPUT:
            IDelay: number of samples by which the 'working' sensor's data
                    should be shifted to best align (correlate) with the
                    'reference' sensor's data
        """
        # calculate distances from source to the two sensors
        src2Ref = np.linalg.norm(self.srcLoc - self.Sensors[iSnsrRef].coords)
        src2Wrk = np.linalg.norm(self.srcLoc - self.Sensors[iSnsrWrk].coords)
        # determine the differential time-of-arrival (tRef - tWrk) by dividing
        # the corresponding distance difference by the speed of sound
        DTOA = (src2Wrk - src2Ref)/self.sndSpd
        # determine the no. of samples' delay from the sampling time period
        IDelay = int(round(DTOA/self.dt))
        return IDelay

    def calcIDelaysAll(self):
        """ populate the 'IDelays' square matrix """
        for iRef in range(self.nSensors):
            for iWrk in range(iRef+1,self.nSensors):
                # calculate 'IDelay' of 'iWrk' sensor w.r.t. 'iRef' sensor
                self.IDelays[iRef,iWrk] = self.calcIDelayPair(iRef,iWrk)
                # calculate its mirror analogue
                self.IDelays[iWrk,iRef] = - self.IDelays[iRef,iWrk]

    def calcCentroid(self,iSnsrs=[]):
        """ calculate centroid of cluster, or a subset of its sensors
        
            INPUTS:
            iSnsrs: list of sensor indices in cluster to use for centroid;
                    default is all, as indicated by [] input
            
            OUTPUTS:
            centroid: 1d array of centroidal coordinates
        """
        if iSnsrs == []:
            iSnsrs = range(self.nSensors)
        nCoords = len(self.Sensors[0].coords)
        # centroid of cluster (double list comprehension: (a) over all specified
        # sensors for a particular coordinate, and (b) over all coordinates)
        return np.array([np.mean([self.Sensors[iSnsr].coords[iDim] \
            for iSnsr in iSnsrs]) for iDim in range(nCoords)])

    def plot(self,fmt='ko-',fignum=None,snsrOrderIn=None):
        """ plot geometry of the sensor cluster in 3d
            
            INPUTS:
            fmt:         plot line format for arms connecting common sensor to
                         others
            fignum:      figure no. on whose 'gca' to plot; None implies create
            snsrOrderIn: list of sensor indices in cluster to plot (not all
                         sensors in the cluster need be used), with first entry
                         indicating the common sensor; None implies all
        """
        if snsrOrderIn is None:
            snsrOrder = range(self.nSensors)
        else:
            snsrOrder = snsrOrderIn
        # x-, y- and z-coordinates of sensors
        crdsX = np.array([self.Sensors[i].coords[0] for i in snsrOrder])
        crdsY = np.array([self.Sensors[i].coords[1] for i in snsrOrder])
        crdsZ = np.array([self.Sensors[i].coords[2] for i in snsrOrder])
        if fignum is not None and plt.fignum_exists(fignum):
            plt.figure(fignum) #set figure no. to active
            ax = plt.gca() #retrieve current axis handle, or create one
        else: #figure no. is not supplied, or the one supplied doesn't exist
            ax = pltTools.plot3dInit() #initiate a 3d figure, and get its axis
        for iSnsrTo in range(1,len(crdsX)): #go thru non-common sensors
            # plot arms of cluster from common sensor (sensor 0)
            ax.plot(crdsX[[0,iSnsrTo]],crdsY[[0,iSnsrTo]],crdsZ[[0,iSnsrTo]],fmt)
        pltTools.set_aspect_equal_3d(ax) #set axis equal
        plt.show()
        return plt.gcf().number

# endclass Cluster

class EnvironmentSim(object):
    """ class for managing the environment of a problem, specifically the
        sensor clusters deployed, in a simulation where the source location is
        known a priori

        ATTRIBUTES:
        srcLoc:    coordinates of source
        config:    configuration object
        nClusters: number of sensor clusters deployed in environment
        Clusters:  'Cluster' objects' list corresponding to sensor clusters
        nSensors:  total number of sensors in environment, across all clusters

        METHODS:
        calcIDelaysAll: calculate 'IDelays' of all clusters
    """
    
    def __init__(self,srcLoc,configIn,dataFldr='.'):
        """ initialization
        
            INPUTS:
            srcLoc:    coordinates of source
            configIn:  configuration object, or filename of same
            dataFldr:  path to data folder (default: pwd)
        """
        # refer back to supplied configuration object, or retrieve same from
        # filename, whichever is supplied in 'configIn'
        self.srcLoc = srcLoc
        self.config = Config_Gunshot(configIn)
        self.nClusters = len(self.config.snsrClstrs)
        self.Clusters = []
        self.nSensors = 0
        # register all sensor clusters in the environment: populate 'Clusters'
        # list with objects of 'ClusterSim' class
        for iClstr in range(self.nClusters):
            self.Clusters.append(ClusterSim(srcLoc,self.config,iClstr,dataFldr))
            self.nSensors += self.Clusters[-1].nSensors

    def calcIDelaysAll(self):
        """ calculate 'IDelays' of all clusters
        """
        for Clstr in self.Clusters: #go thru all clusters
            # calculate 'IDelays' for cluster
            Clstr.calcIDelaysAll()

# endclass Environment
