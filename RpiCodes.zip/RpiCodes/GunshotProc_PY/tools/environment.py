#!/usr/bin/python

#  \brief classes for managing environment, cluster and sensor
#  \author A. Sinha

import os, math, warnings
import numpy as np
from matplotlib import pyplot as plt

from MyPythonCodes.tools import pltTools

from . import Config_Gunshot

filenameSensLoc = 'sensor_locations.txt'

my_eps = 1.e3*np.finfo(np.float64).eps


class Sensor(object):

    def __init__(self,chnl_data,configIn,sensorNo,coords,dataFldr='.'):

        config = Config_Gunshot(configIn)
        self.sensorNo = sensorNo

        self.coords = np.zeros((3),dtype=np.float)
        self.coords[:coords.shape[0]] = np.array(coords)

        self.data = None
        self.snsr_data = chnl_data

    def rtrvData(self):
        self.data = self.snsr_data[self.sensorNo]

    def initSnsr(self):
        self.rtrvData()

    def initSnsrFile(self):
        self.initSnsr()


class Cluster(object):

    def __init__(self,chnl_data,configIn,clusterNo,dataFldr='.'):

        config = Config_Gunshot(configIn)
        self.clusterNo = clusterNo
        self.iSensors = config.snsrClstrs[clusterNo]
        self.nSensors = len(self.iSensors)
        self.Sensors = []
        self.Delays = np.zeros((self.nSensors,self.nSensors),dtype=np.float)
        self.dt = config.dt
        self.clstr_data = chnl_data

        coords = np.loadtxt(os.path.join(dataFldr,filenameSensLoc),comments="#")

        for iSns in range(self.nSensors):
            self.Sensors.append(Sensor(self.clstr_data,config,self.iSensors[iSns], \
                coords[self.iSensors[iSns]],dataFldr))

        self.Dists = np.zeros((self.nSensors,self.nSensors))

        for iSnsr in range(self.nSensors):
            for jSnsr in range(iSnsr+1,self.nSensors):
                self.Dists[iSnsr,jSnsr] = self.interSnsrDist(iSnsr,jSnsr)
                self.Dists[jSnsr,iSnsr] = self.Dists[iSnsr,jSnsr]

        self.centroid = self.calcCentroid()

    def rtrvData(self):
        self.Sensors[0].initSnsrFile()
        self.calcDelaysAll()

    def interSnsrDist(self,iSnsrRef,iSnsrWrk):
        return np.linalg.norm(self.Sensors[iSnsrWrk].coords \
            - self.Sensors[iSnsrRef].coords)

    def interSnsrAngHz(self,iSnsrRef,iSnsrWrk):
        angle = math.atan2(\
            self.Sensors[iSnsrWrk].coords[1]-self.Sensors[iSnsrRef].coords[1],\
            self.Sensors[iSnsrWrk].coords[0]-self.Sensors[iSnsrRef].coords[0])
        if angle < 0:
            angle = angle + 2*math.pi
        return angle

    def calcDelayPair(self,iSnsrRef,iSnsrWrk):
        snsrRef = self.Sensors[iSnsrRef]
        snsrWrk = self.Sensors[iSnsrWrk]

        snsrWrk.rtrvData()

        corrArray = np.correlate(snsrRef.data,snsrWrk.data,'full')

        JDelay = np.argmax(corrArray)

        IDelay = (len(snsrRef.data)-1) - JDelay

        if JDelay == 0:
            corrPkNghbr = corrArray[:3]
        elif JDelay == len(corrArray) - 1:
            corrPkNghbr = corrArray[-3:]
        else:
            corrPkNghbr = corrArray[(JDelay-1):(JDelay+2)]
        if abs(corrPkNghbr[0]-2*corrPkNghbr[1]+corrPkNghbr[2]) > my_eps:
            DelFrctn = 0.5*(corrPkNghbr[0]-corrPkNghbr[2]) \
                /(corrPkNghbr[0]-2*corrPkNghbr[1]+corrPkNghbr[2])
        else:
            DelFrctn = 0.

        return (IDelay - DelFrctn)*self.dt

    def calcDelaysAll(self):
        for iRef in range(self.nSensors):
            for iWrk in range(iRef+1,self.nSensors):
                self.Delays[iRef,iWrk] = self.calcDelayPair(iRef,iWrk)
                self.Delays[iWrk,iRef] = - self.Delays[iRef,iWrk]

    def calcCentroid(self,iSnsrs=[]):
        if iSnsrs == []:
            iSnsrs = range(self.nSensors)

        nCoords = len(self.Sensors[0].coords)

        return np.array([np.mean([self.Sensors[iSnsr].coords[iDim] \
            for iSnsr in iSnsrs]) for iDim in range(nCoords)])

    def plot(self,fmt='ko-',fignum=None,snsrOrderIn=None):

        if snsrOrderIn is None:
            snsrOrder = range(self.nSensors)
        else:
            snsrOrder = snsrOrderIn
        crdsX = np.array([self.Sensors[i].coords[0] for i in snsrOrder])
        crdsY = np.array([self.Sensors[i].coords[1] for i in snsrOrder])
        crdsZ = np.array([self.Sensors[i].coords[2] for i in snsrOrder])
        if fignum is not None and plt.fignum_exists(fignum):
            plt.figure(fignum) #set figure no. to active
            ax = plt.gca()
        else:
            ax = pltTools.plot3dInit() #initiate a 3d figure, and get its axis
        for iSnsrTo in range(1,len(crdsX)): #go thru non-common sensors

            ax.plot(crdsX[[0,iSnsrTo]],crdsY[[0,iSnsrTo]],crdsZ[[0,iSnsrTo]],fmt)
        pltTools.set_aspect_equal_3d(ax) #set axis equal
        plt.show()
        return plt.gcf().number


class Environment(object):

    def __init__(self,chnl_data,configIn,dataFldr='.'):

        self.config = Config_Gunshot(configIn)
        self.nClusters = len(self.config.snsrClstrs)
        self.Clusters = []
        self.nSensors = 0
        self.envdata = chnl_data
        self.dt = self.config.dt

        for iClstr in range(self.nClusters):
            self.Clusters.append(Cluster(self.envdata,self.config,iClstr,dataFldr))
            self.nSensors += self.Clusters[-1].nSensors

    def rtrvData(self):

        for Clstr in self.Clusters:
            Clstr.rtrvData()
