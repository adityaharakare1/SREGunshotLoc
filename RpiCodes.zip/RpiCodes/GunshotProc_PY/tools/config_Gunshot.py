#!/usr/bin/env python

#  \brief interpret config file for gunshot project
#  \author A. Sinha

import sys

from MyPythonCodes.tools import Config

Config_Fname = 'config.cfg'

class Config_Gunshot(Config):
    """ config_LEE = Config_LEE(filename="")
        
        Starts a config class inherited from Config, with added specific
        handling info for some parameters
        
        for usage, attributes and methods, see super class
    """    
    
    def __init__(self,*args,**kwarg):
        # look for filename in inputs, retrieve it, and remove from args/kwarg
        if args:
            if isinstance(args[0],str):
                filename = args[0]
                args = args[1:]
            elif args[0] is None:
                filename = None
                args = args[1:]
            else:
                filename = ''
        elif kwarg.has_key('filename'):
            filename = kwarg['filename']
            del kwarg['filename']
        else:
            filename = ''
        
        if filename is None or filename.lower() == 'none':
            filename = Config_Fname


        # initialize Config (either empty or with config object)
        super(Config_Gunshot,self).__init__(*args,**kwarg)

        # insert parameters that require special handling
        #problem definition
        self.insert_prm('fdpk','int') #floating-point data precision kind (4/8)
        self.insert_prm('dt','float') #sampling period (sec)
        self.insert_prm('nSensors','int') #no. of sensors in environment
        self.insert_prm('sndSpd','float') #speed of sound in ambient
        self.insert_prm('tBfr','float') #time length of interest before event
        self.insert_prm('tAft','float') #time length of interest after event
        self.insert_prm('snsrClstrs','fnc',self._snsrClstrs_read, \
            self._snsrClstrs_write) #sensor clusters definition

        # read config if it exists
        if filename:
            try:
                self.read(filename)
            except IOError:
                print 'Could not find config file: %s' % filename
	    except:
		print 'Unexpected error: ',sys.exc_info()[0]
		raise
        
        self._filename = filename

    def _snsrClstrs_read(self,this_value):
        # Semicolon-separated list of clusters' sensor indices, each w/ format
        #    ( regType | iSnsr1, iSnsr2, ... )
        #   regType: cluster registration type
        #            0 => all sensor indices are listed explicitly
        #            1 => all sensor indices between iSnsr1 and iSnsr2 are in
        #                 present cluster
        # Return: list of lists, each defining indices of sensors in a cluster
        this_value = ''.join(this_value.split()) # remove white space
        info_Unitary = this_value.split(";") # split into unitary definitions
        clstrSnsrLists = [] # initialize empty list of lists of sensor indices
        for infoClstr in info_Unitary: # process each cluster definition
            if not infoClstr: continue
            # split this cluster definition into type and list
            infoParts = infoClstr.strip("()").split("|")
            assert len(infoParts)==2, '2 tokens per cluster definition'
            # registration type
            infoReg = int(infoParts[0])
            infoSnsrs = infoParts[1].split(",")
            if infoReg == 1:
                assert len(infoSnsrs)==2, '2 tokens per in sequence definition'
                clstrSnsrLists.append(list(range(int(infoSnsrs[0]), \
                    int(infoSnsrs[1])+1)))
            elif infoReg == 0:
                clstrSnsrLists.append([int(iSnsr) for iSnsr in infoSnsrs])
            else:
                raise Exception('infoReg = '+str(infoReg)+' not coded')
        #   verify that sensor list is proper:
        #   1. List must contain all sensor indices from 0 to max sensor index
        #   2. Multiple clusters may share a sensor
        # start by flattening list of lists of sensor indices across clusters
        iSnsrsAll = [iSnsr for iSnsrs in clstrSnsrLists for iSnsr in iSnsrs]
        # now compare the sorted version of the above list sans duplications
        # (the latter ensured by converting the list to a 'set') with the
        # appropriate range set
        #if set(sorted(iSnsrsAll)) <> set(range(0,max(iSnsrsAll)+1)):
            #raise Exception('Improper metadata of snsrClstrs: '+this_value)
        return clstrSnsrLists
    
    def _snsrClstrs_write(self,this_value):
        # See comments on read counterpart
        import StringIO
        output = StringIO.StringIO()
        nClstrs = len(this_value)
        if not nClstrs:
            output.write("NONE")
        for infoSnsrs,iClstr in zip(this_value,range(len(this_value))):
            if cmp(infoSnsrs,range(infoSnsrs[0],infoSnsrs[-1]+1)):
                output.write('(0|'+','.join([str(ii) for ii in infoSnsrs])+')')
            else:
                output.write('(1|'+str(infoSnsrs[0])+','+str(infoSnsrs[-1])+')')
            if iClstr+1 < nClstrs:
                output.write('; ')
        return output.getvalue()

#: endclass Config_Gunshot
