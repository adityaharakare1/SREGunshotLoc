from optparse import OptionParser
import numpy as np
import detect

data = np.empty((4,454))

for i in range(4):
	with open("pressure_chnl_"+str(i)+".bin","rb") as fl:
		data[i] = np.fromfile(fl,dtype=np.float32)

parser=OptionParser()
parser.add_option("-f", dest="filename")
(options, args) = parser.parse_args()

categorize = detect.EventCategorize(data, options.filename)
evnt_cat = categorize.categorize()
print evnt_cat
