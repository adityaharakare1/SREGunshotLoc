

#!/usr/bin/python 

#  \brief class for solving source location using nonlinear least squares error
#  \author A. Sinha

import numpy as np
from scipy.optimize import minimize

from . import SolverTemplate

class NLLSEMethod(SolverTemplate):
    """ class for solving source location based on nonlinear least squares error
        minimization
    
        ATTRIBUTES: see parent class
        
        METHODS:
        calcSrcLoc: calculate probable source location(s) based on data
                    recorded on all sensors
        _plotSoln:  plot sensor locations, and source location solution
    """
    
    def calcSrcLoc(self,srcLoc0,tEvnt0,refSnsr,plot=False,debug=False):
        """ calculate source location and event instant based on data recorded
            on all sensors
            
            INPUTS:
            srcLoc0: initial guess of source location (1d array of 3 elements)
            tEvnt0:  initial guess of event time instant
            plot:    to plot the results and sensors, or not
            debug:   to write out (to standard output) debugging info, or not
        """
        sndSpd = self.env.config.sndSpd #speed of sound
        dt = self.env.config.dt         #sampling period of data

        def _costFnc(xTry):
            """ sum of squared errors over all sensors, as cost function to be
                minimized.
                
                error for a sensor is the difference between source-to-sensor
                distance and the distance travelled by sound in the time between
                the event instant and its time-of-arrival at the sensor
                
                INPUTS:
                xTry: 4-element 1d array, with first 3 elements constituting the
                      trial source location, and the last element being the
                      trial source event time instant
                
                OUTPUTS:
                retVal: sum of squared errors
            """
            srcLocTry = np.array(xTry[:-1]) #compose trial source location
            tEvntTry = xTry[-1] #trial source event time instant
            retVal = 0.
            Clstr = self.env.Clusters[0]
            for Snsr in Clstr.Sensors: #go thru all sensors in cluster
                    # calculate sum of squared errors in running sum
                    retVal += (np.linalg.norm(srcLocTry - Snsr.coords[:len(srcLocTry)]) \
                               - sndSpd*(Clstr.Delays[refSnsr, Snsr.sensorNo] - tEvntTry))**2 
            return retVal
        
        def _costFncJac(xTry):
            """ Jacobian of cost function (see '_costFnc' for details) """
            srcLocTry = np.array(xTry[:-1])
            tEvntTry = xTry[-1]
            jac = np.zeros((len(xTry)),dtype=np.float)
            Clstr = self.env.Clusters[0]
            for Snsr in Clstr.Sensors: #go thru all sensors in cluster
                    # sensor-to-source distance
                    dist = np.linalg.norm(Snsr.coords[:len(srcLocTry)] - srcLocTry)
                    # distance travelled by sound in the time between the event
                    # instant and its time-of-arrival at the sensor
                    prop = sndSpd*(Clstr.Delays[refSnsr, Snsr.sensorNo] - tEvntTry)
                    for iCrd in range(len(srcLocTry)): #go thru all coordinates
                        # derivative of cost function w.r.t. source location
                        # coordinates, as running sum over all sensors
                        jac[iCrd] += 2*(srcLocTry[iCrd]-Snsr.coords[iCrd]) \
                            *(1-prop/dist)
                    # derivative of cost function w.r.t. event time instant
                    jac[-1] += 2*sndSpd*(dist-prop)
            return jac
        
        def _costFncHess(xTry):
            """ Hessian of cost function (see '_costFnc' for details) """
            srcLocTry = np.array(xTry[:-1])
            tEvntTry = xTry[-1]
            Hess = np.zeros((len(xTry),len(xTry)),dtype=np.float)
            for Clstr in self.env.Clusters: #go thru all clusters in env
                for Snsr in Clstr.Sensors: #go thru all sensors in cluster
                    # sensor-to-source distance
                    dist = np.linalg.norm(Snsr.coords[:len(srcLocTry)] - srcLocTry)
                    # distance travelled by sound in the time between the event
                    # instant and its time-of-arrival at the sensor
                    prop = sndSpd*(Snsr.smplEvnt*dt - tEvntTry)
                    for iCrd in range(len(srcLocTry)):  #go thru all coordinates
                        # projection of distance on this coordinate
                        dist_i = srcLocTry[iCrd]-Snsr.coords[iCrd]
                        # diagonal terms of Hessian w.r.t. source coordinates
                        # have an extra term as follows
                        Hess[iCrd,iCrd] += 2*(1-prop/dist)
                        for jCrd in range(len(srcLocTry)):
                            # terms of Hessian that apply to joint derivative
                            # w.r.t. source coordinates
                            Hess[iCrd,jCrd] += dist_i*prop/dist**3 \
                                *(srcLocTry[jCrd]-Snsr.coords[jCrd])
                        # terms of Hessian that apply to cross derivative
                        # w.r.t. source coordinates and event time instant
                        Hess[iCrd,-1] += sndSpd*dist_i/dist
                        Hess[-1,iCrd] += Hess[iCrd,-1]
                    # second derivative of cost function w.r.t. source event
                    # time instant
                    Hess[-1,-1] += 2*sndSpd**2
            return Hess

        # compose the initial guess solution: list of source location
        # coordinates and source event time instant
        x0 = list(srcLoc0) + [tEvnt0]
        # optimization options
        options={'maxiter': 10000}
        # actual minization
        xRes = minimize(_costFnc, x0, jac=_costFncJac, method='TNC', tol=1e-10,\
            options=options)

        if xRes.success: #successful minization
            # register source location solution in self (singleton list)
            self.srcLocs = xRes.x[:2]
            # register source event instant solution in self (singleton list)
            self.tEvnts = xRes.x[-1]
        else: #unsuccessful
            self.srcLocs = None
            self.tEvnts = None
            if not debug: #unsuccessful and debug = False
                print 'xRes:\n', xRes
        
        if debug:
            print 'xRes:\n', xRes 
            
        if plot and self.srcLocs is not None:
            self._plotSoln()

    #enddef calcSrcLoc

#endclass Solver
