#!/usr/bin/python 

#  \brief Bancroft's solution of source location applied to TDOA or TOA
#  \author A. Sinha

import math
import numpy as np

from . import SolverTemplate

# machine precision (epsilon) for my checks of closeness to zero
my_eps = 1.e26*np.finfo(np.float64).eps

class BancroftMethod(SolverTemplate):
    """ class for implementing Bancroft's method of solving for the source
        location
    
        ATTRIBUTES: see parent class
        
        METHODS:
        _calcSrcLocClstr: calculate possible source location(s) based on data
                          recorded on a cluster of sensors
    """

    def _calcSrcLocClstr(self,iClstr,options):
        """ calculate source location and event instant based on data recorded
            on all sensors
            
            INPUTS:
            iClstr:  index of cluster in environment
            options: dict of solver options (booleans are False by default)
                TDOA:        time-difference-of-arrival method, or TOA method
                autoReorder: automatically reorder sensors to improve accuracy
                plot:        plot the results and sensors
                debug:       write out (to standard output) debugging info

            OUTPUT:
            srcLocs: list of possible source location coordinates (each list
                     element is a 3-element numpy 1D-array)        """

        clstr = self.env.Clusters[iClstr] #retrieve 'Cluster' object

        sndSpd = self.env.config.sndSpd #speed of sound
        dt = self.env.config.dt         #sampling period of data

        # number of data points (number of sensors in cluster
        nDat = clstr.nSensors

        if 'autoReorder' in options and options['autoReorder']:
            snsrOrder = self.getBestSensorOrder(iClstr)
        else:
            snsrOrder = range(nDat)

        # data matrix ('A' in Bancroft's notation)
        A = np.zeros((nDat,3),dtype=np.float)
        for iSnsr in range(nDat):
            A[iSnsr,:-1] = clstr.Sensors[snsrOrder[iSnsr]].coords[:2]
            if 'TDOA' in options and options['TDOA']:
                A[iSnsr,-1] = clstr.Delays[snsrOrder[iSnsr],snsrOrder[0]]
            else:
                A[iSnsr,-1] = clstr.Sensors[snsrOrder[iSnsr]].smplEvnt*dt
            A[iSnsr,-1] *= sndSpd
        
#        A=np.array([[0.5988,0.0043,0.01,0.],[0.0074,-0.5855,0.01,-0.1652
#],[-0.6069,-0.0036,0.01,-0.9912],[0.0016,0.6007,0.01,-0.8260]])      
        print A
        # get solution from Bancroft's method
        ys = _BancroftMethod(A)

        # candidate solutions for source locations
        srcLocs0 = [ysI[:-1] for ysI in ys]

        def getSolnErrorTDOA(iSoln):
            err = 0.
            for iSnsr in range(nDat):
                err += (np.linalg.norm(A[iSnsr,:-1] - srcLocs0[iSoln]) \
                     - np.linalg.norm(A[0,:-1] - srcLocs0[iSoln]) \
                     + A[iSnsr,-1])**2
            return err

        def getSolnErrorTOA(iSoln):
            # candidate solutions for event times
            tEvnts0 = [-ys[i][-1]/sndSpd for i in range(2)]
            err = 0.
            for iSnsr in range(nDat):
                err += (np.linalg.norm(A[iSnsr,:-1] - srcLocs0[iSoln]) \
                    - (A[iSnsr,-1] - tEvnts0[iSoln]*sndSpd))**2
            return err

        # calculate errors in solution
        if 'TDOA' in options and options['TDOA']:
            errors = np.array([getSolnErrorTDOA(i) for i in range(2)])
        else:
            errors = np.array([getSolnErrorTOA(i) for i in range(2)])
        
        if 'debug' in options and options['debug']:
            print 'errors = ',errors            
            print 'srcLocs0[0] = ',srcLocs0[0]
            print 'srcLocs0[1] = ',srcLocs0[1]
        
        # final solution(s) for source locations are those with error less than
        # 'my_eps'
        srcLocs = []
        for iSoln in range(len(srcLocs0)):
            if errors[iSoln] <= my_eps:
                srcLocs.append(srcLocs0[iSoln])
            
        if 'plot' in options and options['plot']:
            self._plotSolnsClstr(iClstr,srcLocs,snsrOrderIn=snsrOrder)
            
        return srcLocs

    #enddef _calcSrcLocClstr

#    def _calcSrcLocClstr(self,iClstr,options):
#        """ calculate source location and event instant based on data recorded
#            on all sensors
#            
#            INPUTS:
#            iClstr:  index of cluster in environment
#            options: dict of solver options (booleans are False by default)
#                TDOA:        time-difference-of-arrival method, or TOA method
#                autoReorder: automatically reorder sensors to improve accuracy
#                plot:        plot the results and sensors
#                debug:       write out (to standard output) debugging info
#
#            OUTPUT:
#            srcLocs: list of possible source location coordinates (each list
#                     element is a 3-element numpy 1D-array)        """
#
#        clstr = self.env.Clusters[iClstr] #retrieve 'Cluster' object
#
#        sndSpd = self.env.config.sndSpd #speed of sound
#        dt = self.env.config.dt         #sampling period of data
#
#        # number of data points (number of sensors in cluster
#        nDat = clstr.nSensors
#
#        if 'autoReorder' in options and options['autoReorder']:
#            snsrOrder = self.getBestSensorOrder(iClstr)
#        else:
#            snsrOrder = range(nDat)
#
#        # data matrix ('A' in Bancroft's notation)
#        A = np.zeros((nDat,4),dtype=np.float)
#        for iSnsr in range(nDat):
#            A[iSnsr,:-1] = clstr.Sensors[snsrOrder[iSnsr]].coords
#            if 'TDOA' in options and options['TDOA']:
#                A[iSnsr,-1] = clstr.IDelays[snsrOrder[iSnsr],snsrOrder[0]]
#            else:
#                A[iSnsr,-1] = clstr.Sensors[snsrOrder[iSnsr]].smplEvnt
#            A[iSnsr,-1] *= dt*sndSpd
#
#        # get solution from Bancroft's method
#        ys = _BancroftMethod(A)
#
#        # candidate solutions for source locations
#        srcLocs0 = [ysI[:-1] for ysI in ys]
#
#        def getSolnErrorTDOA(iSoln):
#            err = 0.
#            for iSnsr in range(nDat):
#                err += (np.linalg.norm(A[iSnsr,:-1] - srcLocs0[iSoln]) \
#                     - np.linalg.norm(A[0,:-1] - srcLocs0[iSoln]) \
#                     + A[iSnsr,-1])**2
#            return err
#
#        def getSolnErrorTOA(iSoln):
#            # candidate solutions for event times
#            tEvnts0 = [-ys[i][-1]/sndSpd for i in range(2)]
#            err = 0.
#            for iSnsr in range(nDat):
#                err += (np.linalg.norm(A[iSnsr,:-1] - srcLocs0[iSoln]) \
#                    - (A[iSnsr,-1] - tEvnts0[iSoln]*sndSpd))**2
#            return err
#
#        # calculate errors in solution
#        if 'TDOA' in options and options['TDOA']:
#            errors = np.array([getSolnErrorTDOA(i) for i in range(2)])
#        else:
#            errors = np.array([getSolnErrorTOA(i) for i in range(2)])
#        
#        if 'debug' in options and options['debug']:
#            print 'errors = ',errors            
#            print 'srcLocs0[0] = ',srcLocs0[0]
#            print 'srcLocs0[1] = ',srcLocs0[1]
#        
#        # final solution(s) for source locations are those with error less than
#        # 'my_eps'
#        srcLocs = []
#        for iSoln in range(len(srcLocs0)):
#            if errors[iSoln] <= my_eps:
#                srcLocs.append(srcLocs0[iSoln])
#            
#        if 'plot' in options and options['plot']:
#            self._plotSolnsClstr(iClstr,srcLocs,snsrOrderIn=snsrOrder)
#            
#        return srcLocs
#
#    #enddef _calcSrcLocClstr

#endclass BancroftMethod

def _BancroftMethod(A):
    """ implements Bancroft's method for solving the localization/triangulation
        problem:
        (a) in the localization problem, the signal emitted from a source is
            recorded simultaneously at multiple (n) sensors, and this data is
            used to determine the location of the source
        (b) in the converse triangulation problem, the signals emitted
            simultaneously from multiple (n) sources are recorded at a sensor,
            and this data is used to determine the location of the sensor itself
        
        This amounts to solving the following (possibly over-determined) set of
        equations
            t_i = d(x,s_i) + b,    for i in {1, ..., n}
        where d(g,h) is the distance between two points with coordinates g & h,
        s_i: ith sensor (resp. source) location in localization (resp.
             triangulation) problem,
        x:   unknown location of source (resp. sensor) in above problem
        t_i: measured quantity for ith sensor (resp. source)
        b:   unknown 'offset'
        
        INPUTS:
        A: 2D array with 'n' (i.e. no. of data-points) rows, each row being of
           the form
               s_i_x, s_i_y, s_i_z, t_i,
           where s_i_x is the x-coordinate of the ith sensor (resp. source), etc
        
        OUTPUTS:
        ys: list of two solutions vectors, each solution being a 4-element array
            of the form
                x_x, x_y, x_z, -b,
            where x_x is the x-coordinate of the source (resp. sensor), etc.
    """

    def _MinkowskiFncnl(aVec,bVec):
#        if len(aVec) <> 4 or len(bVec) <> 4:
#            raise Exception('Only accepts 4-element vectors')
        return np.dot(aVec[:-1],bVec[:-1]) - aVec[-1]*bVec[-1]

    # number of data points = number of sensors (resp. sources)
    nDat = np.shape(A)[0]

    # weight matrix
    W = np.identity(nDat)
    
    # (A^t)*W
    AtW = np.einsum('ij,ik->jk',A,W)
    
    # generalized inverse (At*W*A)^(-1)*(At*W)
    B = np.linalg.solve(np.einsum('ij,jk->ik',AtW,A),AtW)
    
    # identity vector
    i0Vec = np.ones((nDat),dtype=np.float)
    
    # data vector
    rVec = np.array([_MinkowskiFncnl(A[i,:],A[i,:])/2. for i in range(nDat)])
    
    # 'u' vector
    uVec = np.einsum('ij,j->i',B,i0Vec)
    
    # 'v' vector
    vVec = np.einsum('ij,j->i',B,rVec)
    
    # scalar coefficients 'E', 'F' and 'G'
    ECoeff = _MinkowskiFncnl(uVec,uVec)
    FCoeff = _MinkowskiFncnl(uVec,vVec) - 1.
    GCoeff = _MinkowskiFncnl(vVec,vVec)

    # discriminant of quadratic equation with above coefficients
    disc = FCoeff**2 - ECoeff*GCoeff
    print disc
#    if disc < 0.:
#        raise Exception('Discriminant is negative')
    
    # solutions of quadratic equation
    lambdas = (- FCoeff + np.array([+1., -1.])*math.sqrt(abs(disc)))/ECoeff
    
    # solution vectors
    ys = [lambdaI*uVec + vVec for lambdaI in lambdas]

    return ys

#enddef _BancroftMethod
